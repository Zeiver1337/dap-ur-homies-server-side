package com.dap.dapurhomies;

import com.dap.dapurhomies.interaction.DapSessionManager;
import com.dap.dapurhomies.interaction.GrabYeetHandler;
import com.dap.dapurhomies.interaction.InteractionModules;
import com.dap.dapurhomies.interaction.PlayerInteractionState;
import com.dap.dapurhomies.util.TickClock;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ModLifecycle {
    private static int purgeTickCounter = 0;
    private static final Set<UUID> handSwingingLastTick = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> jumpHeldLastTick = ConcurrentHashMap.newKeySet();

    static void register() {
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.field_14140.method_5667();

            UUID heldId = GrabYeetHandler.getHeldId(id);
            if (heldId != null) {
                class_3222 held = server.method_3760().method_14602(heldId);
                if (held != null) {
                    held.method_5848();
                    Lang.sendActionBar(held, "Your carrier disconnected!", "携带你的玩家已断开连接！");
                }
            }

            // If disconnecting player is being held, notify their holder
            UUID holderId = GrabYeetHandler.getHolderId(id);
            if (holderId != null) {
                class_3222 holder = server.method_3760().method_14602(holderId);
                if (holder != null) {
                    Lang.sendActionBar(holder, "Your held player disconnected!", "你携带的玩家已断开连接！");
                }
            }

            InteractionModules.cleanupAll(id);
            handSwingingLastTick.remove(id);
            jumpHeldLastTick.remove(id);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            DapUrHomiesMod.serverInstance = server;
            TickClock.update(server);
            if (!DapUrHomiesMod.modEnabled) return;
            InteractionModules.tickAll(server);
            boolean hasAnyHolding = PlayerInteractionState.hasAnyHolding();
            for (var player : server.method_3760().method_14571()) {
                // Detect a fresh jump while being held -> attempt escape (documented feature)
                if (GrabYeetHandler.isHeld(player)) {
                    boolean jumping = player.method_63562().comp_3163();
                    boolean wasJumping = jumpHeldLastTick.contains(player.method_5667());
                    if (jumping && !wasJumping) {
                        GrabYeetHandler.tryEscape(player);
                    }
                    if (jumping) jumpHeldLastTick.add(player.method_5667());
                    else jumpHeldLastTick.remove(player.method_5667());
                } else {
                    jumpHeldLastTick.remove(player.method_5667());
                }

                // Detect left-click while holding someone (handSwinging rising edge)
                // This catches left-clicks on AIR (AttackEntityCallback only fires on entities)
                // Skip check if nobody is holding anyone (performance optimization)
                if (hasAnyHolding && GrabYeetHandler.isHolding(player)) {
                    boolean isSwinging = player.field_6252;
                    boolean wasSwinging = handSwingingLastTick.contains(player.method_5667());
                    if (isSwinging && !wasSwinging && !GrabYeetHandler.justGrabbed(player.method_5667())) {
                        if (GrabYeetHandler.isCharging(player.method_5667())) {
                            GrabYeetHandler.releaseCharge(player);   // charged -> yeet
                        } else {
                            GrabYeetHandler.tryDrop(player);          // not charged -> drop
                        }
                    }
                    if (isSwinging) handSwingingLastTick.add(player.method_5667());
                    else handSwingingLastTick.remove(player.method_5667());
                } else {
                    handSwingingLastTick.remove(player.method_5667());
                }

                // Mahito effect: random erratic soul-distortion movement
                if (player.method_6059(DapUrHomiesMod.MAHITO_EFFECT_ENTRY)) {
                    var inst = player.method_6112(DapUrHomiesMod.MAHITO_EFFECT_ENTRY);
                    int amp = (inst != null) ? inst.method_5578() : 0;
                    if (player.method_59922().method_43057() < 0.08f) {
                        double s = 0.15 + amp * 0.05;
                        player.method_5762(
                            (player.method_59922().method_43058() - 0.5) * s,
                            0.08 + player.method_59922().method_43058() * 0.05,
                            (player.method_59922().method_43058() - 0.5) * s
                        );
                        player.field_6037 = true; // Sync velocity to the client.
                    }
                }
            }
            if (++purgeTickCounter >= 200) {
                purgeTickCounter = 0;
                InteractionModules.purgeAll();
            }
        });
    }

    /**
     * Turning the mod off must also release every piece of live state. Otherwise a player
     * who is being carried stays frozen forever: tickAll() is skipped, but the client-side
     * travel cancellation mixin keeps suppressing their movement.
     */
    public static void disableModAndCleanup(class_3222 actor) {
        DapUrHomiesMod.modEnabled = false;
        MinecraftServer server = actor != null ? actor.method_51469().method_8503() : DapUrHomiesMod.serverInstance;
        if (server != null) {
            for (class_3222 online : server.method_3760().method_14571()) {
                UUID id = online.method_5667();
                InteractionModules.cleanupAll(id);
                handSwingingLastTick.remove(id);
                jumpHeldLastTick.remove(id);
            }
        }
        GrabYeetHandler.fullCleanup();
        DapSessionManager.clearAll();
        if (actor != null) Lang.modDisabled(actor);
    }
}
