package com.dap.dapurhomies.mixin;

import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.interaction.GrabYeetHandler;
import net.minecraft.class_2886;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * RIGHT-click on air/block (with item or block targeted) = start charge / shield toggle
 */
@Mixin(class_3244.class)
public class ServerPlayNetworkHandlerMixin {
    @Shadow
    public class_3222 player;

    @Inject(method = "onPlayerInteractItem", at = @At("HEAD"), cancellable = true)
    private void dapurhomies$chargeOnRightClick(class_2886 packet, CallbackInfo ci) {
        if (!ModConfig.get().enableGrabYeet) return;
        if (!GrabYeetHandler.isHolding(player)) return;
        if (player.method_5715()) { GrabYeetHandler.toggleShieldMode(player); ci.cancel(); return; }
        GrabYeetHandler.startCharge(player);
        ci.cancel();
    }
}

