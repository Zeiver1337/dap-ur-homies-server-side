package com.dap.dapurhomies.mixin;

import com.dap.dapurhomies.interaction.GrabYeetHandler;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While held overhead: ignore ALL movement input (server discards it), but DO NOT lock
 * rotation — the held player can freely look around.
 */
@Mixin(class_1657.class)
public abstract class GrabbedPlayerControlMixin {

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void dapurhomies$ignoreMovement(class_243 movementInput, CallbackInfo ci) {
        class_1657 self = (class_1657)(Object)this;
        if (GrabYeetHandler.isHeld(self.method_5667())) {
            ci.cancel();   // discard movement; rotation (yaw/pitch packets) still apply
        }
    }
}

