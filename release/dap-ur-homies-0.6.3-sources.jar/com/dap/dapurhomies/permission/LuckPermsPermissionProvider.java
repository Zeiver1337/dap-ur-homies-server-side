package com.dap.dapurhomies.permission;

import com.dap.dapurhomies.config.ModConfig;
import java.lang.reflect.Method;
import net.minecraft.class_3222;

/**
 * LuckPerms / Fabric Permissions API bridge.
 * Uses reflection so LuckPerms is an optional dependency.
 *
 * Behaviour:
 *   - canInitiate:  LuckPerms node check  +  file preference fallback
 *   - canReceive:   file preference only by default;
 *                   if ModConfig.luckPermsControlsReceive = true,
 *                   also checks LuckPerms node "dap-ur-homies.receive.<type>"
 */
public class LuckPermsPermissionProvider implements PermissionProvider {
    private final FilePermissionProvider fallback = new FilePermissionProvider();
    private Method checkMethod;
    private boolean available = false;

    public LuckPermsPermissionProvider() {
        try {
            Class<?> permissionsClass = Class.forName("me.lucko.fabric.api.permissions.v0.Permissions");
            checkMethod = permissionsClass.getMethod("check", net.minecraft.class_2168.class, String.class, boolean.class);
            available = true;
        } catch (Exception e) {
            available = false;
        }
    }

    public boolean isAvailable() {
        return available;
    }

    @Override
    public boolean hasPermission(class_3222 player, String node) {
        if (!available) return fallback.hasPermission(player, node);
        try {
            return (boolean) checkMethod.invoke(null, player.method_64396(), node, fallback.hasPermission(player, node));
        } catch (Exception e) {
            return fallback.hasPermission(player, node);
        }
    }

    @Override
    public boolean canInitiate(class_3222 player, String type) {
        // LuckPerms for permission check, fallback to file for preference
        String node = "dap-ur-homies." + type;
        boolean hasPerm = hasPermission(player, node);
        if (!hasPerm) return false;
        // Also check personal preference (file-based)
        return fallback.canInitiate(player, type);
    }

    @Override
    public boolean canReceive(class_3222 player, String type) {
        // Default: file-based preference only (players control their own receive settings)
        if (!ModConfig.get().luckPermsControlsReceive) {
            return fallback.canReceive(player, type);
        }
        // Optional: LuckPerms can override receive permissions via "dap-ur-homies.receive.<type>"
        String node = "dap-ur-homies.receive." + type;
        boolean hasPerm = hasPermission(player, node);
        if (!hasPerm) return false;
        // Still respect personal file preference as final gate
        return fallback.canReceive(player, type);
    }

    @Override
    public void setPreference(class_3222 player, String type, boolean value) {
        fallback.setPreference(player, type, value);
    }

    @Override
    public PlayerPreferences getPerms(class_3222 player) {
        return fallback.getPerms(player);
    }

    @Override
    public PlayerPreferences getPerms(java.util.UUID playerId) {
        return fallback.getPerms(playerId);
    }

    @Override
    public String getLang(java.util.UUID playerId) {
        return fallback.getLang(playerId);
    }

    @Override
    public void setLang(java.util.UUID playerId, String lang) {
        fallback.setLang(playerId, lang);
    }
}

