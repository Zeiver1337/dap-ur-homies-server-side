package com.dap.dapurhomies.permission;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_3222;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class FilePermissionProvider implements PermissionProvider {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File FILE = FabricLoader.getInstance().getConfigDir().resolve("dap-ur-homies-perms.json").toFile();
    private final Map<UUID, PlayerPreferences> perms = new ConcurrentHashMap<>();

    public FilePermissionProvider() {
        load();
    }

    @Override
    public boolean hasPermission(class_3222 player, String node) {
        if (node.equals("dap-ur-homies.admin")) {
            var perms = player.method_64396().method_75037();
            if (perms instanceof net.minecraft.class_12086) {
                return ((net.minecraft.class_12086) perms).method_75009().method_75026() >= 2;
            }
            return false;
        }
        return true;
    }

    @Override
    public boolean canInitiate(class_3222 player, String type) {
        return get(player.method_5667()).allows(type);
    }

    @Override
    public boolean canReceive(class_3222 player, String type) {
        return get(player.method_5667()).allows(type);
    }

    @Override
    public void setPreference(class_3222 player, String type, boolean value) {
        get(player.method_5667()).set(type, value);
        save();
    }

    @Override
    public PlayerPreferences getPerms(class_3222 player) {
        return get(player.method_5667());
    }

    @Override
    public PlayerPreferences getPerms(UUID playerId) {
        return get(playerId);
    }

    @Override
    public String getLang(UUID playerId) {
        PlayerPreferences p = get(playerId);
        return p.lang != null ? p.lang : "global";
    }

    @Override
    public void setLang(UUID playerId, String lang) {
        PlayerPreferences p = get(playerId);
        p.lang = lang;
        save();
    }

    private PlayerPreferences get(UUID playerId) {
        return perms.computeIfAbsent(playerId, k -> new PlayerPreferences());
    }

    public void load() {
        if (!FILE.exists()) return;
        try (FileReader r = new FileReader(FILE)) {
            Type type = new TypeToken<Map<String, PlayerPreferences>>(){}.getType();
            Map<String, PlayerPreferences> raw = GSON.fromJson(r, type);
            if (raw != null) {
                perms.clear();
                for (Map.Entry<String, PlayerPreferences> e : raw.entrySet()) {
                    if (e.getValue() == null) continue;
                    try {
                        perms.put(UUID.fromString(e.getKey()), e.getValue());
                    } catch (IllegalArgumentException ignored) {
                        System.err.println("[DapUrHomies] Skipping invalid UUID in permissions: " + e.getKey());
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            System.err.println("[DapUrHomies] Failed to load permissions: " + e.getMessage());
        }
    }

    public void save() {
        try {
            FILE.getParentFile().mkdirs();
            Map<String, PlayerPreferences> raw = new ConcurrentHashMap<>();
            for (Map.Entry<UUID, PlayerPreferences> e : perms.entrySet()) {
                raw.put(e.getKey().toString(), e.getValue());
            }
            try (FileWriter w = new FileWriter(FILE)) {
                GSON.toJson(raw, w);
            }
        } catch (IOException e) {
            System.err.println("[DapUrHomies] Failed to save permissions: " + e.getMessage());
        }
    }
}

