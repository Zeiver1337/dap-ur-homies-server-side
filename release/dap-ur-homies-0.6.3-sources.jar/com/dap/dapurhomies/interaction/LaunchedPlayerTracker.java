package com.dap.dapurhomies.interaction;

import net.minecraft.class_2398;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks launched/thrown players and plays trail particle effects.
 * Ported from original Dap-ur-homie project.
 */
public class LaunchedPlayerTracker {

    private static final Map<UUID, Integer> launchedTicks = new HashMap<>();
    private static final int TRAIL_DURATION = 20; // 1 second of particle trail

    public static void markPlayerAsLaunched(UUID playerId) {
        launchedTicks.put(playerId, 0);
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Integer>> it = launchedTicks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> entry = it.next();
            UUID id = entry.getKey();
            int ticks = entry.getValue();

            class_3222 player = server.method_3760().method_14602(id);
            if (player == null || !player.method_5805()) {
                it.remove();
                continue;
            }

            if (ticks < TRAIL_DURATION) {
                playLaunchTrailEffects(player);
                entry.setValue(ticks + 1);
            } else {
                it.remove();
            }
        }
    }

    private static void playLaunchTrailEffects(class_3222 player) {
        var world = player.method_51469();
        var pos = player.method_73189();

        // Cloud trail
        world.method_65096(class_2398.field_11204,
                pos.field_1352, pos.field_1351 + 0.5, pos.field_1350,
                2, 0.15, 0.15, 0.15, 0.02);

        // Crit sparkles for high-speed flight
        if (player.method_18798().method_1027() > 1.0) {
            world.method_65096(class_2398.field_11205,
                    pos.field_1352, pos.field_1351 + 0.5, pos.field_1350,
                    1, 0.1, 0.1, 0.1, 0.05);
        }
    }

    public static void cleanup(UUID playerId) {
        launchedTicks.remove(playerId);
    }
}

