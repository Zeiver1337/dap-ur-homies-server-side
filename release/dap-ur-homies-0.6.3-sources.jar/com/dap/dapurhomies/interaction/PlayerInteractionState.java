package com.dap.dapurhomies.interaction;

import java.util.UUID;
import net.minecraft.class_3222;

/**
 * Facade for cross-module player interaction state queries.
 * Callers (router, main tick loop) depend on this single entry point
 * instead of reaching into every handler's static state maps.
 */
public final class PlayerInteractionState {
    private PlayerInteractionState() {}

    public static boolean isHeld(UUID id) {
        return GrabYeetHandler.isHeld(id);
    }

    public static boolean isHolding(class_3222 player) {
        return GrabYeetHandler.isHolding(player);
    }

    public static boolean hasAnyHolding() {
        return GrabYeetHandler.hasAnyHolding();
    }

    public static boolean isThrownFlying(UUID id) {
        return GrabYeetHandler.isThrownFlying(id);
    }

    public static boolean isHugging(UUID id) {
        return HugHandler.isHugging(id);
    }

    public static boolean isInDapSession(UUID id) {
        return DapSessionManager.isInSession(id);
    }

    /** Right-click exclusion set (mirrors the router's historical semantics). */
    public static boolean isBusyForUse(class_3222 self, class_3222 target) {
        return isHeld(target.method_5667()) || isHeld(self.method_5667())
                || isThrownFlying(target.method_5667())
                || isHugging(target.method_5667())
                || isInDapSession(self.method_5667()) || isInDapSession(target.method_5667());
    }

    /** Left-click (attack) exclusion set (mirrors the router's historical semantics). */
    public static boolean isBusyForAttack(class_3222 self, class_3222 target) {
        return isHeld(target.method_5667()) || isHeld(self.method_5667())
                || isThrownFlying(target.method_5667()) || isThrownFlying(self.method_5667())
                || isHugging(target.method_5667())
                || isInDapSession(self.method_5667()) || isInDapSession(target.method_5667());
    }
}
