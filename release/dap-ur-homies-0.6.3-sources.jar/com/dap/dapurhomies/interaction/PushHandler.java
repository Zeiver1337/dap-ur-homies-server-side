package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.util.TickClock;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Push system - ported from original Dap-ur-homie project.
 * Features: push immunity, ceiling detection, tiered push power.
 */
public class PushHandler {

    private static final Map<UUID, Long> pushImmunity = new HashMap<>();
    private static final long PUSH_IMMUNITY_TICKS = TickClock.msToTicks(500);

    // Unified push velocity: ~5 blocks high, 8 blocks far
    private static final double PUSH_VELOCITY = 1.2;

    public static class_1269 handlePush(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return class_1269.field_5811;
        if (sp.equals(target)) return class_1269.field_5811;
        if (!ModConfig.get().enablePush) return class_1269.field_5811;

        double dist = sp.method_5739(target);
        if (dist > ModConfig.get().pushRange) return class_1269.field_5811;

        if (!PlayerPermissionManager.canInitiate(sp, "push")) {
            Lang.interactionBlocked(sp, "Push is disabled for you!", "你的推功能已关闭！");
            return class_1269.field_5814;
        }
        if (!PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")
                && !PlayerPermissionManager.canReceive(target, "push")) {
            Lang.targetDisabledType(sp, target, "push");
            return class_1269.field_5814;
        }

        if (InteractionCooldowns.rejectIfBlocked(sp, "push")) return class_1269.field_5814;

        if (isImmune(target.method_5667())) return class_1269.field_5811;

        executePush(sp, target);
        return class_1269.field_5812;
    }

    private static void executePush(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return;
        applyPush(sp, target, PUSH_VELOCITY);
    }

    private static void applyPush(class_3222 sp, class_3222 target, double velocity) {
        if (sp == null || target == null) return;
        class_3218 w = sp.method_51469();
        if (w == null) return;

        // Original project: target.addVelocity(0, velocity, 0) - vertical launch
        double ceilingHeight = getCeilingHeight(target);
        double actualVelocity = velocity;
        if (ceilingHeight < 10 && ceilingHeight > 0) {
            double maxH = Math.max(2, ceilingHeight - 1);
            double v = Math.sqrt(2 * 0.08 * 20 * maxH);
            actualVelocity = Math.min(v, velocity);
        }

        UUID carriedId = GrabYeetHandler.getHeldId(target.method_5667());
        if (carriedId != null) {
            var srv = w.method_8503();
            if (srv != null) {
                class_3222 carried = srv.method_3760().method_14602(carriedId);
                if (carried != null) {
                    carried.method_5762(0, actualVelocity + 0.2, 0);
                    carried.field_6037 = true;
                    pushImmunity.put(carriedId, TickClock.now() + PUSH_IMMUNITY_TICKS);
                }
            }
        }

        // Calculate horizontal away direction for knockback
        class_243 awayDir = target.method_73189().method_1020(sp.method_73189()).method_1029();
        awayDir = new class_243(awayDir.field_1352, 0, awayDir.field_1350).method_1029();
        if (awayDir.method_1027() < 0.001) awayDir = new class_243(1, 0, 0);

        target.method_5762(awayDir.field_1352 * actualVelocity * 0.8, actualVelocity * 0.6, awayDir.field_1350 * actualVelocity * 0.8);
        target.field_6037 = true;

        pushImmunity.put(target.method_5667(), TickClock.now() + PUSH_IMMUNITY_TICKS);

        class_243 mid = sp.method_73189().method_1019(target.method_73189()).method_1021(0.5).method_1031(0, 1.2, 0);
        w.method_65096(class_2398.field_11204, mid.field_1352, mid.field_1351, mid.field_1350, 6, 0.3, 0.2, 0.3, 0.05);
        w.method_43128(null, mid.field_1352, mid.field_1351, mid.field_1350, class_3417.field_14999, class_3419.field_15248, 1.0f, 1.0f);

        sp.method_23667(net.minecraft.class_1268.field_5808, true);
        Lang.pushSuccess(sp, target);
        InteractionCooldowns.applyShared(sp.method_5667(), target.method_5667(), "push", ModConfig.get().pushCooldownMs);
        com.dap.dapurhomies.compat.DanseCompat.playPush(sp, target); // Danse animation
    }

    private static double getCeilingHeight(class_3222 player) {
        class_3218 world = player.method_51469();
        class_2338 pos = class_2338.method_49638(player.method_73189());
        int maxCheck = 20;
        for (int i = 1; i <= maxCheck; i++) {
            if (!world.method_8320(pos.method_10086(i)).method_26215()) return i;
        }
        return maxCheck;
    }

    private static boolean isImmune(UUID playerId) {
        Long endTime = pushImmunity.get(playerId);
        return endTime != null && TickClock.now() < endTime;
    }

    public static void tick(MinecraftServer server) {
        cleanupExpired();
    }

    private static void cleanupExpired() {
        long now = TickClock.now();
        pushImmunity.entrySet().removeIf(e -> now >= e.getValue());
    }

    public static void cleanup(UUID playerId) {
        pushImmunity.remove(playerId);
    }

    public static void purgeExpiredCooldowns() {
        cleanupExpired();
    }
}

