package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.DapUrHomiesMod;
import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.util.TickClock;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_8111;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Fall Catch system - ported from original Dap-ur-homie project.
 * Players can enter "catch ready" mode to catch falling players within range.
 * Pure server-side implementation.
 */
public class FallCatchHandler {

    public static final double CATCH_RANGE_HORIZONTAL = 3.0;
    public static final double CATCH_RANGE_VERTICAL = 4.0;
    public static final long CATCH_WINDOW_TICKS = TickClock.msToTicks(500);
    public static final long CATCH_COOLDOWN_TICKS = TickClock.msToTicks(1000);

    // ===== STATE MAPS =====
    private static final Map<UUID, Long> catchReadyTime = new HashMap<>();   // playerId -> readyStartTime
    private static final Map<UUID, Long> catchCooldowns = new HashMap<>();     // playerId -> cooldownEndTime
    private static final Map<UUID, Boolean> successfulCatch = new HashMap<>(); // playerId -> caught someone this window

    public static void register() {
        // Tick is driven by InteractionModules.tickAll(); do not register another server tick here.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof class_3222 fallingPlayer)) return true;
            if (DapUrHomiesMod.isModEnabled() == false) return true;
            if (!source.method_49708(class_8111.field_42345)) return true;
            if (fallingPlayer.field_6017 < 3.0f) return true;
            if (!ModConfig.get().enableGrabYeet) return true; // Use grab toggle for now

            class_3222 catcher = findCatcher(fallingPlayer);
            if (catcher != null) {
                playCatchEffects(fallingPlayer, catcher);
                successfulCatch.put(catcher.method_5667(), true);
                return false; // Cancel fall damage
            }
            return true;
        });
    }

    // ===== PUBLIC API =====

    public static class_1269 enterCatchReady(class_3222 player) {
        if (player == null) return class_1269.field_5811;
        if (!ModConfig.get().enableGrabYeet) return class_1269.field_5811;
        if (!PlayerPermissionManager.canInitiate(player, "grab")) {
            Lang.interactionBlocked(player, "Grab is disabled for you!", "你的抓取功能已关闭！");
            return class_1269.field_5814;
        }

        UUID playerId = player.method_5667();

        if (isOnCatchCooldown(playerId)) {
            Lang.sendActionBar(player, "§c Catch on cooldown!", "§c 接住冷却中！");
            return class_1269.field_5814;
        }

        if (catchReadyTime.containsKey(playerId)) {
            // Already ready, cancel it
            catchReadyTime.remove(playerId);
            successfulCatch.remove(playerId);
            Lang.sendActionBar(player, "§7 Catch ready cancelled.", "§7 取消接住准备。");
            return class_1269.field_5812;
        }

        catchReadyTime.put(playerId, TickClock.now());
        successfulCatch.put(playerId, false);
        Lang.sendActionBar(player, "§a Catch ready! (500ms window)", "§a 准备接住！(500ms窗口)");
        return class_1269.field_5812;
    }

    public static boolean isOnCatchCooldown(UUID playerId) {
        Long cooldownEnd = catchCooldowns.get(playerId);
        if (cooldownEnd == null) return false;
        if (TickClock.now() >= cooldownEnd) {
            catchCooldowns.remove(playerId);
            return false;
        }
        return true;
    }

    // ===== TICK =====

    public static void tick(MinecraftServer server) {
        long now = TickClock.now();

        Iterator<Map.Entry<UUID, Long>> it = catchReadyTime.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Long> entry = it.next();
            UUID playerId = entry.getKey();
            long readyTime = entry.getValue();

            // Window expired
            if (now - readyTime > CATCH_WINDOW_TICKS) {
                if (!successfulCatch.getOrDefault(playerId, false)) {
                    // Missed - apply cooldown
                    catchCooldowns.put(playerId, now + CATCH_COOLDOWN_TICKS);

                    class_3222 player = server.method_3760().method_14602(playerId);
                    if (player != null) {
                        Lang.sendActionBar(player, "§c Catch missed! 1s cooldown", "§c 接住失败！1秒冷却");
                    }
                }
                it.remove();
                successfulCatch.remove(playerId);
            }
        }
    }

    // ===== FIND CATCHER =====

    private static class_3222 findCatcher(class_3222 fallingPlayer) {
        class_3218 world = fallingPlayer.method_51469();
        long now = TickClock.now();

        class_238 searchBox = new class_238(
                fallingPlayer.method_23317() - CATCH_RANGE_HORIZONTAL,
                fallingPlayer.method_23318() - CATCH_RANGE_VERTICAL,
                fallingPlayer.method_23321() - CATCH_RANGE_HORIZONTAL,
                fallingPlayer.method_23317() + CATCH_RANGE_HORIZONTAL,
                fallingPlayer.method_23318() + CATCH_RANGE_VERTICAL,
                fallingPlayer.method_23321() + CATCH_RANGE_HORIZONTAL
        );

        for (class_1657 player : world.method_18456()) {
            if (player == fallingPlayer) continue;
            if (!(player instanceof class_3222 catcher)) continue;

            UUID catcherId = catcher.method_5667();

            // Must be in catch ready mode
            Long readyTime = catchReadyTime.get(catcherId);
            if (readyTime == null) continue;

            // Check window
            if (now - readyTime > CATCH_WINDOW_TICKS) continue;

            // Check cooldown
            if (isOnCatchCooldown(catcherId)) continue;

            // Check range
            if (!searchBox.method_1006(catcher.method_73189())) continue;

            // Permissions: catcher must be allowed to grab, falling player must accept grabs
            if (!PlayerPermissionManager.canInitiate(catcher, "grab")) continue;
            if (!PlayerPermissionManager.hasPermission(catcher, "dap-ur-homies.admin")
                    && !PlayerPermissionManager.canReceive(fallingPlayer, "grab")) continue;

            double dx = fallingPlayer.method_23317() - catcher.method_23317();
            double dz = fallingPlayer.method_23321() - catcher.method_23321();
            double horizontalDist = Math.sqrt(dx * dx + dz * dz);

            if (horizontalDist <= CATCH_RANGE_HORIZONTAL) {
                return catcher;
            }
        }

        return null;
    }

    // ===== EFFECTS =====

    private static void playCatchEffects(class_3222 caught, class_3222 catcher) {
        class_3218 world = catcher.method_51469();
        double x = (caught.method_23317() + catcher.method_23317()) / 2;
        double y = catcher.method_23318() + 1.5;
        double z = (caught.method_23321() + catcher.method_23321()) / 2;

        world.method_43128(null, x, y, z,
                class_3417.field_14840, class_3419.field_15248, 1.2f, 0.7f);
        world.method_43128(null, x, y, z,
                class_3417.field_14627, class_3419.field_15248, 1.0f, 1.2f);
        world.method_43128(null, x, y, z,
                class_3417.field_15048, class_3419.field_15248, 1.0f, 0.8f);

        world.method_65096(class_2398.field_11204, x, y, z, 12, 0.4, 0.3, 0.4, 0.02);
        world.method_65096(class_2398.field_11205, x, y, z, 8, 0.3, 0.3, 0.3, 0.1);
        world.method_65096(class_2398.field_29642, x, y, z, 6, 0.2, 0.2, 0.2, 0.02);

        caught.method_18800(0, 0, 0);
        caught.field_6037 = true;

        Lang.sendActionBar(caught, "§a§l " + catcher.method_5477().getString() + " caught you!",
                "§a§l " + catcher.method_5477().getString() + " 接住了你！");
        Lang.sendActionBar(catcher, "§a§l PERFECT CATCH! " + caught.method_5477().getString(),
                "§a§l 完美接住！" + caught.method_5477().getString());
    }

    // ===== CLEANUP =====

    public static void cleanup(UUID playerId) {
        catchReadyTime.remove(playerId);
        catchCooldowns.remove(playerId);
        successfulCatch.remove(playerId);
    }
}

