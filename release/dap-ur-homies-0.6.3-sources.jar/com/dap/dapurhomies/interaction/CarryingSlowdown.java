package com.dap.dapurhomies.interaction;

import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;

/**
 * Applies speed slowdown to players who are holding/grabbing other players.
 * Ported from original Dap-ur-homie project.
 */
public class CarryingSlowdown {

    public static final float CARRY_SPEED_MULTIPLIER = 0.6f;
    private static final double SLOWDOWN_AMOUNT = -(1.0 - CARRY_SPEED_MULTIPLIER) * 0.1;
    private static final class_2960 MODIFIER_ID = class_2960.method_60655("dap-ur-homies", "carrying_slowdown");

    public static void tick(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            updateSlowdown(player);
        }
    }

    private static void updateSlowdown(class_3222 player) {
        boolean isCarrying = GrabYeetHandler.isHolding(player);

        class_1324 speedAttr = player.method_5996(class_5134.field_23719);
        if (speedAttr == null) return;

        var existingModifier = speedAttr.method_6199(MODIFIER_ID);

        if (isCarrying) {
            if (existingModifier == null) {
                speedAttr.method_26835(new class_1322(
                        MODIFIER_ID,
                        SLOWDOWN_AMOUNT,
                        class_1322.class_1323.field_6328
                ));
            }
        } else {
            if (existingModifier != null) {
                speedAttr.method_6200(MODIFIER_ID);
            }
        }
    }
}

