package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.DapUrHomiesMod;
import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.util.TickClock;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1531;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

final class HumanShieldController {
    private static final Map<UUID, class_1531> shieldStands = new HashMap<>(); // holder -> armorstand
    private static final Map<UUID, Boolean> shieldModeActive = new HashMap<>();     // holder -> active
    private static final Map<UUID, Long> shieldSwapCooldown = new HashMap<>();      // holder -> cooldown end time
    private static final long SHIELD_SWAP_COOLDOWN_TICKS = TickClock.msToTicks(1000); // 1 second cooldown

    private HumanShieldController() {
    }

    static class_1269 toggleShieldMode(class_3222 holder) {
        if (holder == null) return class_1269.field_5811;
        UUID hid = holder.method_5667();
        if (GrabYeetHandler.getHeldId(hid) == null) return class_1269.field_5811;

        // Check shield swap cooldown
        Long cooldownEnd = shieldSwapCooldown.get(hid);
        if (cooldownEnd != null && TickClock.now() < cooldownEnd) {
            long remainingTicks = cooldownEnd - TickClock.now();
            long remaining = (remainingTicks + 19) / 20;
            Lang.sendActionBar(holder, "\u00a7c\ud83d\udee1 Shield swap cooldown! " + remaining + "s",
                "\u00a7c\ud83d\udee1 \u76fe\u724c\u5207\u6362\u51b7\u5374\u4e2d\uff01\u8fd8\u5269 " + remaining + "\u79d2");
            return class_1269.field_5814;
        }

        if (Boolean.TRUE.equals(shieldModeActive.get(hid))) {
            disableShieldMode(holder, true);
        } else {
            enableShieldMode(holder);
        }
        return class_1269.field_5812;
    }

    private static void enableShieldMode(class_3222 holder) {
        UUID hid = holder.method_5667();
        UUID tid = GrabYeetHandler.getHeldId(hid);
        if (tid == null) return;

        var server = holder.method_51469().method_8503();
        if (server == null) return;
        class_3222 held = server.method_3760().method_14602(tid);
        if (held == null) return;

        // Create armor stand as intermediate carrier
        class_1531 stand = new class_1531(class_1299.field_6131, holder.method_51469());
        stand.method_5648(true);
        // stand.setMarker(true); // requires accesswidener
        stand.method_5875(true);
        stand.method_5684(true);
        stand.method_5803(true);
        // stand.setSmall(true); // requires accesswidener

        class_243 pos = holder.method_73189();
        stand.method_23327(pos.field_1352, pos.field_1351, pos.field_1350);
        (holder.method_51469()).method_8649(stand);

        // Move held player to stand
        held.method_5848();
        if (!held.method_5873(stand, true, false)) {
            // If the stand cannot accept the passenger, discard it and abort shield mode.
            stand.method_31472();
            return;
        }

        shieldStands.put(hid, stand);
        shieldModeActive.put(hid, true);
        shieldSwapCooldown.put(hid, TickClock.now() + SHIELD_SWAP_COOLDOWN_TICKS);

        Lang.sendActionBar(holder, "\u00a7aHuman shield activated!");
    }

    static void disableShieldMode(class_3222 holder, boolean notify) {
        UUID hid = holder.method_5667();
        UUID tid = GrabYeetHandler.getHeldId(hid);
        if (tid == null) return;

        var server = holder.method_51469().method_8503();
        if (server == null) return;
        class_1531 stand = shieldStands.get(hid);

        if (stand != null) {
            if (stand.method_31483() != null) stand.method_31483().method_5848();
            stand.method_31472();
            shieldStands.remove(hid);
        }

        // Never re-ride the holder: passenger sync would override the authoritative
        // requestTeleport applied by tickCarryPositions().
        shieldModeActive.put(hid, false);
        shieldSwapCooldown.put(hid, TickClock.now() + SHIELD_SWAP_COOLDOWN_TICKS);
        if (notify) {
            Lang.sendActionBar(holder, "§cHuman shield deactivated!");
        }
    }

    static boolean isActive(UUID holderId) {
        return Boolean.TRUE.equals(shieldModeActive.get(holderId));
    }

    static class_1531 getStand(UUID holderId) {
        return shieldStands.get(holderId);
    }

    static void clearForEscape(UUID holderId) {
        class_1531 stand = shieldStands.remove(holderId);
        if (stand != null) stand.method_31472();
        shieldModeActive.remove(holderId);
    }

    static void cleanup(UUID playerId) {
        class_1531 stand = shieldStands.remove(playerId);
        if (stand != null) stand.method_31472();
        shieldModeActive.remove(playerId);
        shieldSwapCooldown.remove(playerId);
    }

    static void removeSwapCooldown(UUID playerId) {
        shieldSwapCooldown.remove(playerId);
    }

    static void fullCleanup() {
        for (class_1531 stand : shieldStands.values()) {
            if (stand != null) stand.method_31472();
        }
        shieldStands.clear();
        shieldModeActive.clear();
        shieldSwapCooldown.clear();
    }

    static void registerShieldDamageEvent() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!DapUrHomiesMod.isModEnabled()) return true;
            if (!(entity instanceof class_3222 holder)) return true;
            UUID hid = holder.method_5667();
            if (!Boolean.TRUE.equals(shieldModeActive.get(hid))) return true;

            UUID heldId = GrabYeetHandler.getHeldId(hid);
            if (heldId == null) return true;
            var server = holder.method_51469().method_8503();
            if (server == null) return true;
            class_3222 shield = server.method_3760().method_14602(heldId);
            if (shield != null && shield.method_5805()) {
                shield.method_64397(holder.method_51469(), source, amount);
                return false; // Cancel damage to holder, redirect to held player
            }
            return true;
        });
    }
}
