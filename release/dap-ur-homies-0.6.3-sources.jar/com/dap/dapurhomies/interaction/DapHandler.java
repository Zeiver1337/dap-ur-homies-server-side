package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.util.CooldownManager;
import com.dap.dapurhomies.util.TickClock;
import net.minecraft.class_1269;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DapHandler {
    private static final Map<UUID, Long> pendingHighFive = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> chargeStart = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> chargeLevels = new ConcurrentHashMap<>();
    private static final Map<UUID, UUID> chargeTarget = new ConcurrentHashMap<>();
    private static final long HIGH_FIVE_WINDOW_TICKS = TickClock.msToTicks(800);
    private static final long[] CHARGE_THRESHOLDS = {0, 10, 20, 30, 40, 50};
    private static final long MAX_CHARGE_TICKS = TickClock.msToTicks(3000);
    private static final long CHARGE_TIMEOUT_TICKS = 200;
    private static final long CYCLE_CHARGE_TICKS = TickClock.msToTicks(8000); // 8s for cycle mode
    private static final long CYCLE_CHARGE_TIMEOUT_TICKS = 400; // 20s for cycle mode

    // Perfect Dap: a max-level release stays "answerable" for this long (1.5s).
    // Replaces the old 2-tick charge-START sync requirement which was humanly impossible.
    private static final long PERFECT_WINDOW_TICKS = TickClock.msToTicks(1500);
    private static final Map<UUID, PendingPerfect> pendingPerfect = new ConcurrentHashMap<>();

    private record PendingPerfect(UUID targetId, int level, long releaseTick) {}

    private static final int SPEED_HISTORY_TICKS = 30;
    private static final double SPEED_TIER_1 = 5.0, SPEED_TIER_2 = 7.5, SPEED_TIER_3 = 12.0;
    private static final Map<UUID, LinkedList<Double>> speedHistory = new ConcurrentHashMap<>();

    private static final Map<UUID, PendingHighFive> pendingEffects = new ConcurrentHashMap<>();
    private static final long HIT_EFFECT_DELAY_TICKS = TickClock.msToTicks(100);

    private static class PendingHighFive {
        final class_3222 p1, p2;
        final class_243 pos;
        final int tier;
        final long effectTime;
        PendingHighFive(class_3222 p1, class_3222 p2, class_243 pos, int tier, long effectTime) {
            this.p1 = p1; this.p2 = p2; this.pos = pos; this.tier = tier; this.effectTime = effectTime;
        }
    }

    public static void tick(MinecraftServer server) {
        long now = TickClock.now();
        for (class_3222 player : server.method_3760().method_14571()) {
            tickSpeedHistory(player);
            tickCharge(player);
        }
        Iterator<Map.Entry<UUID, PendingHighFive>> it = pendingEffects.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PendingHighFive> e = it.next();
            if (now >= e.getValue().effectTime) {
                PendingHighFive fx = e.getValue();
                boolean online = server.method_3760().method_14602(fx.p1.method_5667()) != null
                        && server.method_3760().method_14602(fx.p2.method_5667()) != null;
                if (online) {
                    DapVisualEffects.executeHighFiveEffects(fx.p1, fx.p2, fx.pos, fx.tier);
                }
                it.remove();
            }
        }
    }

    private static void tickSpeedHistory(class_3222 player) {
        UUID id = player.method_5667();
        double speed = player.method_18798().method_1033() * 20.0;
        LinkedList<Double> history = speedHistory.computeIfAbsent(id, k -> new LinkedList<>());
        history.addLast(speed);
        while (history.size() > SPEED_HISTORY_TICKS) history.removeFirst();
    }

    private static double getMaxRecentSpeed(UUID playerId) {
        LinkedList<Double> history = speedHistory.get(playerId);
        if (history == null || history.isEmpty()) return 0.0;
        double max = 0.0;
        for (Double s : history) if (s > max) max = s;
        return max;
    }

    public static class_1269 startCharge(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return class_1269.field_5811;
        if (!ModConfig.get().enableDap) return class_1269.field_5811;
        if (sp.method_51469() != target.method_51469()) return class_1269.field_5811;
        if (sp.method_5739(target) > ModConfig.get().dapRange) return class_1269.field_5811;
        if (!PlayerPermissionManager.canInitiate(sp, "dap")) {
            Lang.interactionBlocked(sp, "Dap is disabled for you!", "你的碰拳功能已关闭！");
            return class_1269.field_5814;
        }
        if (InteractionCooldowns.rejectIfBlocked(sp, "dap")) return class_1269.field_5814;
        if (!PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")
                && !PlayerPermissionManager.canReceive(target, "dap")) {
            Lang.targetDisabledType(sp, target, "dap");
            return class_1269.field_5814;
        }
        if (DapSessionManager.isInSession(sp.method_5667()) || DapSessionManager.isInSession(target.method_5667()))
            return class_1269.field_5811;

        // Mode 1 (cycle-charge): if already charging, release instead
        // In cycle mode, a second click releases the current charge; this must precede
        // the general charging check below, which would otherwise return PASS first.
        if (ModConfig.get().chargedDapMode == 1 && isCharging(sp.method_5667())) {
            releaseCharge(sp);
            return class_1269.field_5812;
        }

        if (isCharging(sp.method_5667())) return class_1269.field_5811;
        // Mutual charging is allowed; reject only when the target is charging someone else.
        // Perfect Dap requires both players to be able to charge each other.
        UUID targetChargeTarget = chargeTarget.get(target.method_5667());
        if (targetChargeTarget != null && !targetChargeTarget.equals(sp.method_5667()))
            return class_1269.field_5811;

        chargeStart.put(sp.method_5667(), TickClock.now());
        chargeLevels.put(sp.method_5667(), 0);
        chargeTarget.put(sp.method_5667(), target.method_5667());
        Lang.chargeStart(sp);
        return class_1269.field_5812;
    }

    public static class_1269 handleNormalDap(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return class_1269.field_5811;
        if (!ModConfig.get().enableDap) return class_1269.field_5811;
        if (sp.method_51469() != target.method_51469()) return class_1269.field_5811;
        if (sp.method_5739(target) > ModConfig.get().dapRange) return class_1269.field_5811;
        if (!PlayerPermissionManager.canInitiate(sp, "dap")) {
            Lang.interactionBlocked(sp, "Dap is disabled for you!", "你的碰拳功能已关闭！");
            return class_1269.field_5814;
        }
        long now = TickClock.now();
        if (InteractionCooldowns.rejectIfBlocked(sp, "dap")) return class_1269.field_5814;
        if (!PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")
                && !PlayerPermissionManager.canReceive(target, "dap")) {
            Lang.targetDisabledType(sp, target, "dap");
            return class_1269.field_5814;
        }
        if (DapSessionManager.isInSession(sp.method_5667()) || DapSessionManager.isInSession(target.method_5667()))
            return class_1269.field_5811;
        if (isCharging(sp.method_5667()) || isCharging(target.method_5667()))
            return class_1269.field_5811;
        UUID sid = sp.method_5667(), tid = target.method_5667();
        Long pending = pendingHighFive.get(tid);
        boolean highFiveAllowed = ModConfig.get().enableHighFive
                && sp.method_5739(target) <= ModConfig.get().highFiveRange;
        if (highFiveAllowed && pending != null && now - pending < HIGH_FIVE_WINDOW_TICKS) {
            if (!PlayerPermissionManager.canInitiate(sp, "highFive")) {
                Lang.interactionBlocked(sp, "High-five is disabled for you!", "你的击掌功能已关闭！");
                return class_1269.field_5814;
            }
            if (!PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")
                    && !PlayerPermissionManager.canReceive(target, "highFive")) {
                Lang.targetDisabledType(sp, target, "highFive");
                return class_1269.field_5814;
            }
            if (InteractionCooldowns.rejectIfBlocked(sp, "highFive")) return class_1269.field_5814;
            executeHighFive(sp, target);
            InteractionCooldowns.applyShared(sid, tid, "highFive", ModConfig.get().highFiveCooldownMs);
            pendingHighFive.remove(tid); pendingHighFive.remove(sid);
            return class_1269.field_5812;
        }
        pendingHighFive.put(sid, now);
        executeDap(sp, target, 1);
        InteractionCooldowns.apply(sid, "dap", ModConfig.get().dapCooldownMs);
        return class_1269.field_5812;
    }

    public static void tickCharge(class_3222 player) {
        if (player == null) return;
        UUID id = player.method_5667();
        Long start = chargeStart.get(id);
        if (start == null) return;
        long elapsed = TickClock.now() - start;

        int mode = ModConfig.get().chargedDapMode;
        if (mode == 0) {
            // Mode 0: hold-charge (original) — release when not sneaking or exceeded max charge time
            if (!player.method_5715() || elapsed > MAX_CHARGE_TICKS) { releaseCharge(player); return; }
            int newLevel = 0;
            for (int i = CHARGE_THRESHOLDS.length - 1; i >= 0; i--) {
                if (elapsed >= CHARGE_THRESHOLDS[i]) { newLevel = i; break; }
            }
            Integer oldLevel = chargeLevels.get(id);
            if (oldLevel == null || newLevel != oldLevel) {
                chargeLevels.put(id, newLevel);
                Lang.chargeLevel(player, newLevel);
            }
        } else {
            // Mode 1: cycle-charge — 8s session with looping levels 0->5->0 (triangular wave)
            if (elapsed > CYCLE_CHARGE_TICKS) { releaseCharge(player); return; }
            double progress = (double) elapsed / CYCLE_CHARGE_TICKS;
            double tri = progress < 0.5 ? progress * 2.0 : (1.0 - progress) * 2.0;
            int newLevel = (int) Math.round(tri * 5.0);
            newLevel = Math.max(0, Math.min(5, newLevel));
            Integer oldLevel = chargeLevels.get(id);
            if (oldLevel == null || newLevel != oldLevel) {
                chargeLevels.put(id, newLevel);
                Lang.chargeLevel(player, newLevel);
            }
        }

        if (TickClock.now() % 4 == 0) {
            class_3218 w = (class_3218) player.method_51469();
            if (w != null) {
                class_243 pos = player.method_73189().method_1031(0, 1, 0);
                w.method_65096(class_2398.field_11205, pos.field_1352, pos.field_1351, pos.field_1350, 2, 0.3, 0.3, 0.3, 0.05);
            }
        }
    }

    public static boolean isCharging(UUID id) { return chargeStart.containsKey(id); }

    /** Abort a charge without firing any effect (used when another interaction wins). */
    public static void cancelCharge(UUID id) {
        if (id == null) return;
        chargeStart.remove(id);
        chargeLevels.remove(id);
        chargeTarget.remove(id);
    }

    public static void releaseCharge(class_3222 player) {
        if (player == null) return;
        UUID id = player.method_5667();
        Long start = chargeStart.remove(id);
        Integer level = chargeLevels.remove(id);
        UUID targetId = chargeTarget.remove(id);
        if (start == null) return;
        int powerLevel = (level != null) ? level : 0;
        class_3222 target = null;
        if (targetId != null) {
            var server = ((class_3218) player.method_51469()).method_8503();
            if (server != null) target = server.method_3760().method_14602(targetId);
        }
        if (target == null || target.method_51469() != player.method_51469()
                || player.method_5739(target) > ModConfig.get().dapRange) {
            Lang.chargeCancelled(player);
            InteractionCooldowns.apply(id, "dap", ModConfig.get().dapCooldownMs);
            return;
        }

        int maxLevel = CHARGE_THRESHOLDS.length - 1;
        long now = TickClock.now();

        // Perfect Dap (v0.6.0 rework): I must release at max level, and the partner qualifies by EITHER
        //   a) still max-charging AT ME right now, OR
        //   b) having max-released AT ME within PERFECT_WINDOW_TICKS (pending-release window).
        // The old Mode-0 rule compared charge-START times with a 2-tick (0.1s) tolerance,
        // which was humanly impossible to satisfy.
        Long partnerStart = chargeStart.get(target.method_5667());
        Integer partnerLevel = chargeLevels.get(target.method_5667());
        UUID partnerTarget = chargeTarget.get(target.method_5667());
        boolean partnerIsChargingMe = partnerTarget != null && partnerTarget.equals(id);
        boolean partnerCurrentlyMax = partnerIsChargingMe && partnerStart != null
                && partnerLevel != null && partnerLevel >= maxLevel;

        PendingPerfect pp = pendingPerfect.get(target.method_5667());
        boolean partnerRecentlyReleasedMax = pp != null && pp.targetId().equals(id)
                && pp.level() >= maxLevel && now - pp.releaseTick() <= PERFECT_WINDOW_TICKS;

        boolean bothPerfect = powerLevel >= maxLevel && (partnerCurrentlyMax || partnerRecentlyReleasedMax);

        // Record my max-level release so the partner can answer within the window
        if (powerLevel >= maxLevel) {
            if (bothPerfect) {
                pendingPerfect.remove(target.method_5667());
                pendingPerfect.remove(id);
            } else {
                pendingPerfect.put(id, new PendingPerfect(target.method_5667(), powerLevel, now));
            }
        }

        if (bothPerfect) {
            // consume partner's charge (if still charging)
            chargeStart.remove(target.method_5667());
            chargeLevels.remove(target.method_5667());
            chargeTarget.remove(target.method_5667());
            executePerfectDap(player, target);
            Lang.chargeRelease(player, powerLevel);
            if (partnerLevel != null) Lang.chargeRelease(target, partnerLevel);
            InteractionCooldowns.apply(id, "dap", ModConfig.get().dapCooldownMs);
            InteractionCooldowns.apply(target.method_5667(), "dap", ModConfig.get().dapCooldownMs);
            return;
        }

        executeDap(player, target, powerLevel + 1);
        Lang.chargeRelease(player, powerLevel);
        InteractionCooldowns.apply(id, "dap", ModConfig.get().dapCooldownMs);
        InteractionCooldowns.apply(target.method_5667(), "dap", ModConfig.get().dapCooldownMs);
    }

    public static void cleanup(UUID playerId) {
        pendingHighFive.remove(playerId);
        pendingPerfect.remove(playerId);
        pendingPerfect.entrySet().removeIf(e -> e.getValue().targetId().equals(playerId));
        chargeStart.remove(playerId);
        chargeLevels.remove(playerId);
        chargeTarget.remove(playerId);
        Iterator<Map.Entry<UUID, UUID>> it = chargeTarget.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, UUID> e = it.next();
            if (e.getValue().equals(playerId)) {
                chargeStart.remove(e.getKey());
                chargeLevels.remove(e.getKey());
                it.remove();
            }
        }
        speedHistory.remove(playerId);
        pendingEffects.remove(playerId);
    }

    public static void purgeExpiredCooldowns() {
        long now = TickClock.now();
        pendingHighFive.entrySet().removeIf(e -> now - e.getValue() > HIGH_FIVE_WINDOW_TICKS * 2);
        pendingPerfect.entrySet().removeIf(e -> now - e.getValue().releaseTick() > PERFECT_WINDOW_TICKS * 2);
        int mode = ModConfig.get().chargedDapMode;
        long timeout = (mode == 0) ? CHARGE_TIMEOUT_TICKS : CYCLE_CHARGE_TIMEOUT_TICKS;
        chargeStart.entrySet().removeIf(e -> {
            if (now - e.getValue() > timeout) {
                chargeLevels.remove(e.getKey());
                chargeTarget.remove(e.getKey());
                return true;
            }
            return false;
        });
    }

    private static void executeDap(class_3222 sp, class_3222 target, int power) {
        if (sp == null || target == null) return;
        class_3218 w = (class_3218) sp.method_51469();
        if (w == null) return;
        DapSession session = DapSessionManager.createSession(
                sp.method_5667(), target.method_5667(), 1.2, DapSession.DapType.NORMAL_DAP);
        Runnable effects = () -> {
            class_243 mid = sp.method_73189().method_1019(target.method_73189()).method_1021(0.5).method_1031(0, 1.2, 0);
            int particleCount = 4 + power * 2;
            w.method_65096(class_2398.field_11205, mid.field_1352, mid.field_1351, mid.field_1350, particleCount, 0.2, 0.2, 0.2, 0.1);
            w.method_65096(class_2398.field_11208, mid.field_1352, mid.field_1351, mid.field_1350, power, 0.15, 0.15, 0.15, 0.08);
            float pitch = 1.0f + power * 0.1f;
            // Single clap sound for dap (not a 2-second loop)
            w.method_43128(null, mid.field_1352, mid.field_1351, mid.field_1350, class_3417.field_15204.comp_349(), class_3419.field_15248, 0.9f, pitch);
            sp.method_23667(net.minecraft.class_1268.field_5808, true);
            Lang.dapSuccess(sp, target);
            com.dap.dapurhomies.compat.DanseCompat.playDap(sp, target);
        };
        if (session != null) session.onComplete(effects);
        else effects.run();
    }

    private static void executeHighFive(class_3222 p1, class_3222 p2) {
        if (p1 == null || p2 == null) return;
        class_3218 w = (class_3218) p1.method_51469();
        if (w == null) return;
        double speed1 = getMaxRecentSpeed(p1.method_5667());
        double speed2 = getMaxRecentSpeed(p2.method_5667());
        double maxSpeed = Math.max(speed1, speed2);
        int tier = 0;
        if (maxSpeed >= SPEED_TIER_3) tier = 3;
        else if (maxSpeed >= SPEED_TIER_2) tier = 2;
        else if (maxSpeed >= SPEED_TIER_1) tier = 1;
        DapSession session = DapSessionManager.createSession(
                p1.method_5667(), p2.method_5667(), 1.0, DapSession.DapType.NORMAL_DAP);
        class_243 highFivePos = p1.method_73189().method_1019(p2.method_73189()).method_1021(0.5).method_1031(0, 1.5, 0);
        speedHistory.remove(p1.method_5667());
        speedHistory.remove(p2.method_5667());
        final class_3222 fp1 = p1, fp2 = p2;
        final class_243 fPos = highFivePos;
        final int fTier = tier;
        Runnable onComplete = () -> {
            pendingEffects.put(fp1.method_5667(), new PendingHighFive(fp1, fp2, fPos, fTier, TickClock.now() + HIT_EFFECT_DELAY_TICKS));
            fp1.method_23667(net.minecraft.class_1268.field_5808, true);
            fp2.method_23667(net.minecraft.class_1268.field_5808, true);
            Lang.highFiveSuccess(fp1, fp2, fTier);
            // Perfect high-five (tier 3) plays Danse dap animation
            if (fTier >= 3) {
                com.dap.dapurhomies.compat.DanseCompat.playDap(fp1, fp2);
            } else {
                com.dap.dapurhomies.compat.DanseCompat.playHighFive(fp1, fp2);
            }
            // High-five has its own tier-based sound effects in executeHighFiveEffects(),
            // no need for a 2-second clap loop here
        };
        if (session != null) session.onComplete(onComplete);
        else onComplete.run();
    }

    // Perfect Dap (v0.6.0): dedicated tier-3-level celebration instead of a plain power-6 dap
    private static void executePerfectDap(class_3222 p1, class_3222 p2) {
        if (p1 == null || p2 == null) return;
        class_3218 w = (class_3218) p1.method_51469();
        if (w == null) return;
        DapSession session = DapSessionManager.createSession(
                p1.method_5667(), p2.method_5667(), 1.2, DapSession.DapType.NORMAL_DAP);
        class_243 mid = p1.method_73189().method_1019(p2.method_73189()).method_1021(0.5).method_1031(0, 1.2, 0);
        Runnable effects = () -> {
            p1.method_23667(net.minecraft.class_1268.field_5808, true);
            p2.method_23667(net.minecraft.class_1268.field_5808, true);
            com.dap.dapurhomies.compat.DanseCompat.playDap(p1, p2);
            DapVisualEffects.executeTier3(w, mid, p1, p2);
            Lang.sendActionBar(p1, "§6§l⚡ PERFECT DAP! ⚡", "§6§l⚡ 完美击拳! ⚡");
            Lang.sendActionBar(p2, "§6§l⚡ PERFECT DAP! ⚡", "§6§l⚡ 完美击拳! ⚡");
        };
        if (session != null) session.onComplete(effects);
        else effects.run();
    }

    public static boolean isInBlockingState(UUID id) {
        return CooldownManager.isOnCooldown(id, "dap") || DapSessionManager.isInSession(id);
    }
}

