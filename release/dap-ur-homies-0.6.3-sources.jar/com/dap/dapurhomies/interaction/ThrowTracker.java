package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.compat.ProtectionCompat;
import com.dap.dapurhomies.util.TickClock;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

final class ThrowTracker {
    private static final Map<UUID, PendingThrow> pendingThrows = new HashMap<>();

    private static class PendingThrow {
        final class_243 velocity;
        int ticksRemaining;

        PendingThrow(class_243 velocity, int delayTicks) {
            this.velocity = velocity;
            this.ticksRemaining = delayTicks;
        }
    }

    private static final Map<UUID, ThrownPlayerData> thrownPlayers = new HashMap<>();

    private static class ThrownPlayerData {
        final long throwTick;
        boolean wasOnFire;
        boolean hitWall;
        boolean landed;
        int ticksFlying;

        ThrownPlayerData(long throwTick, boolean wasOnFire) {
            this.throwTick = throwTick;
            this.wasOnFire = wasOnFire;
            this.hitWall = false;
            this.landed = false;
            this.ticksFlying = 0;
        }
    }

    private static final Map<UUID, Long> throwImmunity = new HashMap<>();
    private static final long THROW_IMMUNITY_TICKS = 10;      // 500ms = 10 ticks

    private static final int PENDING_THROW_TICKS = 3;
    private static final double WALL_CHECK_DISTANCE = 1.5;
    private static final float FIRE_EXPLOSION_POWER = 3.0f;

    private ThrowTracker() {
    }

    static boolean isImmune(UUID playerId) {
        Long immuneTick = throwImmunity.get(playerId);
        return immuneTick != null && (TickClock.now() - immuneTick) < 20;
    }

    static void schedulePendingThrow(UUID playerId, class_243 velocity) {
        pendingThrows.put(playerId, new PendingThrow(velocity, PENDING_THROW_TICKS));
    }

    static void registerThrown(UUID playerId, boolean wasOnFire) {
        thrownPlayers.put(playerId, new ThrownPlayerData(TickClock.now(), wasOnFire));
    }

    static void applyImmunity(UUID playerId) {
        throwImmunity.put(playerId, TickClock.now());
    }

    static boolean isThrownFlying(UUID playerId) {
        return thrownPlayers.containsKey(playerId);
    }

    static void tickPendingThrows(MinecraftServer server) {
        Iterator<Map.Entry<UUID, PendingThrow>> it = pendingThrows.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PendingThrow> entry = it.next();
            UUID playerId = entry.getKey();
            PendingThrow pt = entry.getValue();
            pt.ticksRemaining--;

            if (pt.ticksRemaining <= 0) {
                class_3222 player = server.method_3760().method_14602(playerId);
                if (player != null && player.method_5805()) {
                    player.method_18799(pt.velocity);
                    player.field_6037 = true;
                }
                it.remove();
            }
        }
    }

    static void tickThrownPlayers(MinecraftServer server) {
        long nowTick = TickClock.now();
        Iterator<Map.Entry<UUID, ThrownPlayerData>> it = thrownPlayers.entrySet().iterator();

        while (it.hasNext()) {
            Map.Entry<UUID, ThrownPlayerData> entry = it.next();
            UUID playerId = entry.getKey();
            ThrownPlayerData data = entry.getValue();
            class_3222 player = server.method_3760().method_14602(playerId);

            if (player == null || !player.method_5805()) {
                it.remove();
                continue;
            }

            class_243 pos = player.method_73189();
            class_3218 world = player.method_51469();
            data.ticksFlying++;

            // Wall collision check (every 2 ticks to reduce block state queries)
            if (!data.hitWall && data.ticksFlying % 2 == 0) {
                class_243 vel = player.method_18798();
                class_243 checkDir = (vel.method_1027() > 0.001) ? vel.method_1029() : player.method_5828(1.0f);
                class_243 checkPos = pos.method_1019(checkDir.method_1021(WALL_CHECK_DISTANCE));
                class_2338 blockPos = class_2338.method_49638(checkPos);
                class_2680 state = world.method_8320(blockPos);

                if (!state.method_26215() && isBreakable(state)) {
                    // Ignore the first 3 ticks, while velocity direction is still unreliable.
                    // Break walls only at flight speeds of at least 1.2 blocks/tick.
                    if (data.ticksFlying > 3 && player.method_18798().method_1033() >= 1.2) {
                        data.hitWall = true;
                        // Respect claims: the thrown player must not be able to breach protected blocks
                        if (ProtectionCompat.canBuildAt(player, blockPos)) {
                            world.method_22352(blockPos, true);
                        }
                        float hardness = state.method_26214(world, blockPos);
                        double speed = player.method_18798().method_1033();
                        float damage = calculateWallDamage(hardness, speed);
                        player.method_64397(world, world.method_48963().method_48828(), damage);
                        player.method_18799(player.method_18798().method_1021(0.7));
                        player.field_6037 = true;
                        world.method_65096(class_2398.field_11236, checkPos.field_1352, checkPos.field_1351, checkPos.field_1350,
                                3, 0.3, 0.3, 0.3, 0.1);
                        world.method_43128(null, checkPos.field_1352, checkPos.field_1351, checkPos.field_1350,
                                class_3417.field_15026, class_3419.field_15245, 1.0f, 0.8f);
                    }
                }
            }

            // Landing detection
            if (!data.landed) {
                boolean onGround = player.method_24828();
                boolean inWater = player.method_5799();
                boolean nearGround = !world.method_8320(class_2338.method_49637(pos.field_1352, pos.field_1351 - 0.5, pos.field_1350)).method_26215();

                if (onGround || inWater || nearGround) {
                    data.landed = true;

                    // Fire explosion if was on fire
                    if (data.wasOnFire) {
                        world.method_8437(null, pos.field_1352, pos.field_1351, pos.field_1350,
                                FIRE_EXPLOSION_POWER, class_1937.class_7867.field_40888);
                        world.method_65096(class_2398.field_11239, pos.field_1352, pos.field_1351, pos.field_1350,
                                20, 0.5, 0.5, 0.5, 0.1);
                        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350,
                                class_3417.field_15152.comp_349(), class_3419.field_15245, 1.5f, 1.0f);
                    }

                    // Landing particles
                    world.method_65096(class_2398.field_11204, pos.field_1352, pos.field_1351, pos.field_1350,
                            5, 0.3, 0.1, 0.3, 0.05);

                    it.remove();
                    continue;
                }
            }

            // Expire throws after 10 seconds (200 ticks).
            if (nowTick - data.throwTick > 200) {
                it.remove();
            }
        }
    }

    static void cleanupExpiredImmunity() {
        long nowTick = TickClock.now();
        throwImmunity.entrySet().removeIf(e -> nowTick - e.getValue() > THROW_IMMUNITY_TICKS);
    }

    private static float calculateWallDamage(float hardness, double speed) {
        float baseDamage = hardness * 0.8f;
        float speedMultiplier = (float) Math.min(2.0, speed);
        return Math.max(1.0f, Math.min(10.0f, baseDamage * speedMultiplier));
    }

    private static boolean isBreakable(class_2680 state) {
        // Exclude unbreakable blocks
        return !state.method_27852(class_2246.field_9987)
                && !state.method_27852(class_2246.field_10540)
                && !state.method_27852(class_2246.field_22423)
                && !state.method_27852(class_2246.field_38420)
                && !state.method_27852(class_2246.field_10034)
                && !state.method_27852(class_2246.field_10380)
                && !state.method_27852(class_2246.field_10443)
                && !state.method_27852(class_2246.field_16328)
                && !state.method_27852(class_2246.field_10603)
                && !state.method_27852(class_2246.field_10327)
                && !state.method_27852(class_2246.field_10525)
                && !state.method_27852(class_2246.field_10395)
                && !state.method_27852(class_2246.field_10263);
    }

    static void cleanup(UUID playerId) {
        pendingThrows.remove(playerId);
        thrownPlayers.remove(playerId);
        throwImmunity.remove(playerId);
    }

    static void fullCleanup() {
        pendingThrows.clear();
        thrownPlayers.clear();
        throwImmunity.clear();
    }

    static void purgeExpiredCooldowns() {
        cleanupExpiredImmunity();
    }
}
