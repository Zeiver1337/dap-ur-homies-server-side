package com.dap.dapurhomies.interaction;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

final class DapVisualEffects {
    static void executeHighFiveEffects(class_3222 p1, class_3222 p2, class_243 pos, int tier) {
        class_3218 world = (class_3218) p1.method_51469();
        switch (tier) {
            case 0 -> executeTier0(world, pos, p1, p2);
            case 1 -> executeTier1(world, pos, p1, p2);
            case 2 -> executeTier2(world, pos, p1, p2);
            case 3 -> executeTier3(world, pos, p1, p2);
        }
    }

    private static void executeTier0(class_3218 world, class_243 pos, class_3222 p1, class_3222 p2) {
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15016, class_3419.field_15248, 1.2f, 1.1f);
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14627, class_3419.field_15248, 0.8f, 1.8f);
        spawnStarBurst(world, pos, 10, 0.3);
        world.method_65096(class_2398.field_11248, pos.field_1352, pos.field_1351, pos.field_1350, 8, 0.1, 0.1, 0.1, 0.08);
        world.method_65096(class_2398.field_29642, pos.field_1352, pos.field_1351, pos.field_1350, 6, 0.2, 0.2, 0.2, 0.02);
    }

    private static void executeTier1(class_3218 world, class_243 pos, class_3222 p1, class_3222 p2) {
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15016, class_3419.field_15248, 1.5f, 1.0f);
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14627, class_3419.field_15248, 1.0f, 2.0f);
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14800, class_3419.field_15248, 0.8f, 1.2f);
        spawnStarBurst(world, pos, 16, 0.5);
        world.method_65096(class_2398.field_11248, pos.field_1352, pos.field_1351, pos.field_1350, 15, 0.15, 0.15, 0.15, 0.12);
        world.method_65096(class_2398.field_29642, pos.field_1352, pos.field_1351, pos.field_1350, 10, 0.25, 0.25, 0.25, 0.03);
        world.method_65096(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, 5, 0.2, 0.2, 0.2, 0.05);
    }

    private static void executeTier2(class_3218 world, class_243 pos, class_3222 p1, class_3222 p2) {
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15016, class_3419.field_15248, 2.0f, 0.9f);
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14917, class_3419.field_15248, 1.2f, 1.0f);
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14627, class_3419.field_15248, 1.2f, 2.0f);
        spawnStarBurst(world, pos, 24, 0.7);
        world.method_65096(class_2398.field_11248, pos.field_1352, pos.field_1351, pos.field_1350, 25, 0.2, 0.2, 0.2, 0.18);
        world.method_65096(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, 15, 0.3, 0.3, 0.3, 0.1);
        world.method_65096(class_2398.field_29642, pos.field_1352, pos.field_1351, pos.field_1350, 15, 0.3, 0.3, 0.3, 0.05);
    }

    static void executeTier3(class_3218 world, class_243 pos, class_3222 p1, class_3222 p2) {
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15152.comp_349(), class_3419.field_15248, 1.2f, 1.3f);
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15188, class_3419.field_15248, 1.5f, 1.0f);
        world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_19167, class_3419.field_15248, 2.0f, 0.5f);
        spawnStarBurst(world, pos, 32, 1.0);
        world.method_65096(class_2398.field_11236, pos.field_1352, pos.field_1351, pos.field_1350, 3, 0.5, 0.5, 0.5, 0);
        world.method_65096(class_2398.field_11248, pos.field_1352, pos.field_1351, pos.field_1350, 40, 0.3, 0.3, 0.3, 0.25);
        world.method_65096(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, 25, 0.5, 0.5, 0.5, 0.15);
        world.method_65096(class_2398.field_22246, pos.field_1352, pos.field_1351, pos.field_1350, 20, 0.4, 0.4, 0.4, 0.1);
        world.method_65096(class_2398.field_11220, pos.field_1352, pos.field_1351, pos.field_1350, 30, 0.5, 0.5, 0.5, 0.3);
        createBattleShockwave(world, pos, p1, p2, 10.0);
        p1.method_7353(net.minecraft.class_2561.method_43470("§6§l⚡ SHOCKWAVE! ⚡"), true);
        p2.method_7353(net.minecraft.class_2561.method_43470("§6§l⚡ SHOCKWAVE! ⚡"), true);
    }

    private static void createBattleShockwave(class_3218 world, class_243 pos, class_3222 p1, class_3222 p2, double radius) {
        for (int ring = 1; ring <= 5; ring++) {
            double r = ring * 2.0;
            int points = (int)(r * 8);
            for (int i = 0; i < points; i++) {
                double angle = Math.toRadians((360.0 / points) * i);
                double x = pos.field_1352 + Math.cos(angle) * r;
                double z = pos.field_1350 + Math.sin(angle) * r;
                if (ring <= 2) {
                    world.method_65096(class_2398.field_11204, x, pos.field_1351, z, 1, 0.1, 0.2, 0.1, 0.02);
                } else if (ring <= 4) {
                    world.method_65096(class_2398.field_11227, x, pos.field_1351 + 0.5, z, 1, 0, 0, 0, 0);
                } else {
                    world.method_65096(class_2398.field_11205, x, pos.field_1351 + 0.5, z, 2, 0.1, 0.1, 0.1, 0.05);
                }
            }
        }
        class_238 pushBox = new class_238(
                pos.field_1352 - radius, pos.field_1351 - radius, pos.field_1350 - radius,
                pos.field_1352 + radius, pos.field_1351 + radius, pos.field_1350 + radius
        );
        for (class_1297 entity : world.method_8335(null, pushBox)) {
            if (entity == p1 || entity == p2) continue;
            double dist = entity.method_73189().method_1022(pos);
            if (dist > radius || dist < 0.5) continue;
            double strength = (1.0 - (dist / radius)) * 4.0 + 1.0;
            class_243 dir = entity.method_73189().method_1020(pos).method_1029();
            if (dir.method_1027() < 0.01) {
                dir = new class_243(Math.random() - 0.5, 0, Math.random() - 0.5).method_1029();
            }
            entity.method_5762(dir.field_1352 * strength, strength * 0.6, dir.field_1350 * strength);
            entity.field_6037 = true;
            world.method_65096(class_2398.field_11205, entity.method_23317(), entity.method_23318() + 1, entity.method_23321(), 5, 0.2, 0.2, 0.2, 0.1);
        }
    }

    private static void spawnStarBurst(class_3218 world, class_243 pos, int rays, double spread) {
        for (int i = 0; i < rays; i++) {
            double angle = (2 * Math.PI * i) / rays;
            double dx = Math.cos(angle) * spread;
            double dz = Math.sin(angle) * spread;
            world.method_65096(class_2398.field_11205, pos.field_1352, pos.field_1351, pos.field_1350, 2, dx, 0.2, dz, 0.15);
        }
    }
}
