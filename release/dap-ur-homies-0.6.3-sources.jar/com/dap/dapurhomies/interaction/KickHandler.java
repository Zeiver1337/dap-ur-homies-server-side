package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.util.TickClock;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5134;
import net.minecraft.class_8111;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Kick system - ported from original Dap-ur-homie project.
 * Features: charge system, DropKick, speed slowdown, push window.
 */
public class KickHandler {

    private static final double NORMAL_KICK_DAMAGE = 2.0;
    private static final double NORMAL_KICK_KNOCKBACK = 1.0; // 3 blocks high, 4 blocks far

    private static final double DROPKICK_RANGE = 3.0;
    private static final double DROPKICK_DAMAGE = 10.0;
    private static final double DROPKICK_KNOCKBACK = 3.5;

    private static final long CHARGE_DURATION_MS = 3000;
    private static final long PUSH_WINDOW_MS = 540;
    private static final double SLOWDOWN_AMOUNT = -0.4;
    private static final double DROPKICK_SLOWDOWN = -0.9;

    // ===== CHARGE STATE (using TickClock ticks) =====
    private static final Map<UUID, Long> chargeStartTime = new HashMap<>();

    // ===== PUSH WINDOW (using TickClock ticks) =====
    private static final Map<UUID, Long> pushWindowEnd = new HashMap<>();

    // ===== SLOWDOWN MODIFIERS =====
    private static final class_2960 KICK_SLOWDOWN_ID = class_2960.method_60655("dap-ur-homies", "kick_slowdown");
    private static final class_2960 DROPKICK_SLOWDOWN_ID = class_2960.method_60655("dap-ur-homies", "dropkick_slowdown");

    // ===== SLOWDOWN EXPIRY TRACKING (using TickClock ticks) =====
    private static final Map<UUID, Long> slowdownExpiry = new HashMap<>();
    private static final long SLOWDOWN_DURATION_TICKS = TickClock.msToTicks(5000); // 5 seconds = 100 ticks

    // ===== COOLDOWN: unified via CooldownManager only =====

    // ===== PUBLIC API =====

    public static class_1269 handleKick(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return class_1269.field_5811;
        if (sp.equals(target)) return class_1269.field_5811;
        if (!ModConfig.get().enableKick) return class_1269.field_5811;
        if (sp.method_51469() != target.method_51469()) return class_1269.field_5811;

        double dist = sp.method_5739(target);
        if (dist > ModConfig.get().kickRange) return class_1269.field_5811;

        // Look angle check: must be looking down at target's feet
        class_243 look = sp.method_5828(1.0f);
        if (look.field_1351 > -0.25) return class_1269.field_5811;

        if (!PlayerPermissionManager.canInitiate(sp, "kick")) {
            Lang.interactionBlocked(sp, "Kick is disabled for you!", "你的踢功能已关闭！");
            return class_1269.field_5814;
        }
        if (!PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")
                && !PlayerPermissionManager.canReceive(target, "kick")) {
            Lang.targetDisabledType(sp, target, "kick");
            return class_1269.field_5814;
        }

        if (InteractionCooldowns.rejectIfBlocked(sp, "kick")) return class_1269.field_5814;

        executeNormalKick(sp, target);
        return class_1269.field_5812;
    }

    // ===== CHARGE SYSTEM =====

    public static void startCharge(class_3222 player) {
        if (player == null) return;
        if (!ModConfig.get().enableKick) return;
        if (!PlayerPermissionManager.canInitiate(player, "kick")) {
            Lang.interactionBlocked(player, "Kick is disabled for you!", "你的踢功能已关闭！");
            return;
        }
        chargeStartTime.put(player.method_5667(), TickClock.now());
        Lang.sendActionBar(player, "DropKick charging... aim at feet and right-click again after 3s",
                "飞踢蓄力中……3 秒后再次右键释放");
    }

    public static class_1269 releaseCharge(class_3222 player) {
        return releaseCharge(player, null);
    }

    public static class_1269 releaseCharge(class_3222 player, class_3222 target) {
        if (player == null) return class_1269.field_5811;
        Long start = chargeStartTime.remove(player.method_5667());
        if (start == null) return class_1269.field_5811;
        if (!ModConfig.get().enableKick) return class_1269.field_5811;

        // The release must pass exactly the same gates as a normal kick / dropkick
        if (!PlayerPermissionManager.canInitiate(player, "kick")) {
            Lang.interactionBlocked(player, "Kick is disabled for you!", "你的踢功能已关闭！");
            return class_1269.field_5814;
        }
        if (InteractionCooldowns.rejectIfBlocked(player, "kick")) return class_1269.field_5814;

        long chargeTicks = TickClock.now() - start;
        if (chargeTicks >= TickClock.msToTicks(CHARGE_DURATION_MS)) {
            return executeDropKick(player);
        }
        // Not fully charged: behave like a normal kick, reusing its validation
        if (target != null) {
            return handleKick(player, target);
        }
        return class_1269.field_5811;
    }

    public static void cancelCharge(UUID playerId) {
        chargeStartTime.remove(playerId);
    }

    public static boolean isCharging(UUID playerId) {
        return chargeStartTime.containsKey(playerId);
    }

    // ===== NORMAL KICK =====

    private static void executeNormalKick(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return;
        class_3218 w = sp.method_51469();
        if (w == null) return;

        UUID id = sp.method_5667();
        // Cooldown was checked by handleKick.

        class_243 dir = target.method_73189().method_1020(sp.method_73189()).method_1029();
        if (dir.method_1027() < 0.001) dir = new class_243(1, 0, 0);

        target.method_5762(dir.field_1352 * NORMAL_KICK_KNOCKBACK, 0.35, dir.field_1350 * NORMAL_KICK_KNOCKBACK); // ~3 blocks high, 4 blocks far
        target.field_6037 = true;
        target.method_64397(w, w.method_48963().method_48796(class_8111.field_42348, sp), (float) NORMAL_KICK_DAMAGE);

        // Apply speed slowdown
        applySlowdown(target, SLOWDOWN_AMOUNT, KICK_SLOWDOWN_ID);
        slowdownExpiry.put(target.method_5667(), TickClock.now() + SLOWDOWN_DURATION_TICKS);

        // Start push window
        pushWindowEnd.put(sp.method_5667(), TickClock.now() + TickClock.msToTicks(PUSH_WINDOW_MS));

        class_243 mid = sp.method_73189().method_1019(target.method_73189()).method_1021(0.5).method_1031(0, 0.5, 0);
        w.method_65096(class_2398.field_11227, mid.field_1352, mid.field_1351, mid.field_1350, 3, 0.2, 0.1, 0.2, 0.05);
        w.method_43128(null, mid.field_1352, mid.field_1351, mid.field_1350, class_3417.field_14706, class_3419.field_15248, 1.0f, 1.0f);

        sp.method_23667(net.minecraft.class_1268.field_5808, true);
        Lang.kickSuccess(sp, target);
        InteractionCooldowns.apply(sp.method_5667(), "kick", ModConfig.get().kickCooldownMs);
        com.dap.dapurhomies.compat.DanseCompat.playKick(sp, target); // Danse animation
    }

    // ===== DROP KICK =====

    private static class_1269 executeDropKick(class_3222 sp) {
        if (sp == null) return class_1269.field_5811;
        class_3218 w = sp.method_51469();
        if (w == null) return class_1269.field_5811;

        UUID id = sp.method_5667();
        // Cooldown was checked by releaseCharge.

        // DropKick affects all eligible living entities in front of the player.
        class_243 eyePos = sp.method_33571();
        class_243 look = sp.method_5828(1.0f);

        boolean hit = false;
        class_238 box = sp.method_5829().method_1014(DROPKICK_RANGE + 0.5);
        for (class_1297 entity : sp.method_51469().method_8333(sp, box,
                e -> e instanceof class_1309 && !e.method_31481() && !e.method_7325())) {
            class_1309 target = (class_1309) entity;
            if (target == sp) continue;
            if (target.method_73183() != sp.method_51469()) continue;
            if (target.method_73189().method_1025(eyePos) > DROPKICK_RANGE * DROPKICK_RANGE) continue;

            // Player targets respect their receive toggle and protection claims
            if (target instanceof class_3222 playerTarget
                    && !PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")) {
                if (!PlayerPermissionManager.canReceive(playerTarget, "kick")) continue;
                if (!com.dap.dapurhomies.compat.ProtectionCompat.canInteract(sp, playerTarget)) continue;
            }

            class_243 toTarget = target.method_73189().method_1020(eyePos).method_1029();
            double dot = look.method_1026(toTarget);
            if (dot < 0.5) continue; // Must be roughly in front

            class_243 dir = target.method_73189().method_1020(sp.method_73189()).method_1029();
            if (dir.method_1027() < 0.001) dir = new class_243(1, 0, 0);

            target.method_5762(dir.field_1352 * DROPKICK_KNOCKBACK, 0.5, dir.field_1350 * DROPKICK_KNOCKBACK); // ~5 blocks high
            target.field_6037 = true;
            target.method_64397(w, w.method_48963().method_48796(class_8111.field_42348, sp), (float) DROPKICK_DAMAGE);

            // Apply heavy slowdown (only for players)
            if (target instanceof class_3222 playerTarget) {
                applySlowdown(playerTarget, DROPKICK_SLOWDOWN, DROPKICK_SLOWDOWN_ID);
                slowdownExpiry.put(playerTarget.method_5667(), TickClock.now() + SLOWDOWN_DURATION_TICKS);
            }

            // Start push window
            pushWindowEnd.put(sp.method_5667(), TickClock.now() + TickClock.msToTicks(PUSH_WINDOW_MS));

            class_243 mid = sp.method_73189().method_1019(target.method_73189()).method_1021(0.5).method_1031(0, 0.5, 0);
            w.method_65096(class_2398.field_11236, mid.field_1352, mid.field_1351, mid.field_1350, 5, 0.3, 0.3, 0.3, 0.1);
            w.method_43128(null, mid.field_1352, mid.field_1351, mid.field_1350, class_3417.field_15152.comp_349(), class_3419.field_15248, 1.5f, 0.8f);

            hit = true;
        }

        if (hit) {
            sp.method_23667(net.minecraft.class_1268.field_5808, true);
            Lang.sendActionBar(sp, "§c DROP KICK!", "§c 飞踢!");
            InteractionCooldowns.apply(sp.method_5667(), "kick", ModConfig.get().kickCooldownMs * 2);
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    // ===== PUSH WINDOW TICK =====

    private static void tickPushWindow(MinecraftServer server) {
        long now = TickClock.now();
        Iterator<Map.Entry<UUID, Long>> it = pushWindowEnd.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Long> entry = it.next();
            if (now >= entry.getValue()) {
                it.remove();
                continue;
            }

            class_3222 kicker = server.method_3760().method_14602(entry.getKey());
            if (kicker == null || !kicker.method_5805()) {
                it.remove();
                continue;
            }

            // Apply small continuous push to entities in front
            class_243 eyePos = kicker.method_33571();
            class_243 look = kicker.method_5828(1.0f);
            for (class_3222 target : server.method_3760().method_14571()) {
                if (target == kicker) continue;
                if (target.method_51469() != kicker.method_51469()) continue;
                if (target.method_73189().method_1025(eyePos) > 4.0) continue;

                class_243 toTarget = target.method_73189().method_1020(eyePos).method_1029();
                if (look.method_1026(toTarget) < 0.7) continue;

                class_243 pushDir = target.method_73189().method_1020(kicker.method_73189()).method_1029();
                target.method_5762(pushDir.field_1352 * 0.15, 0.05, pushDir.field_1350 * 0.15);
                target.field_6037 = true;
            }
        }
    }

    // ===== SLOWDOWN =====

    private static void applySlowdown(class_3222 player, double amount, class_2960 id) {
        class_1324 speedAttr = player.method_5996(class_5134.field_23719);
        if (speedAttr != null) {
            // Remove existing modifier
            speedAttr.method_6200(id);
            // Add new modifier
            class_1322 modifier = new class_1322(
                    id, amount, class_1322.class_1323.field_6328
            );
            speedAttr.method_26835(modifier);
        }
    }

    public static void removeSlowdown(class_3222 player, class_2960 id) {
        class_1324 speedAttr = player.method_5996(class_5134.field_23719);
        if (speedAttr != null) speedAttr.method_6200(id);
    }

    // ===== TICK =====

    /** Auto-release charges once full so a stale charge can never fire later. */
    private static void tickCharges(MinecraftServer server) {
        long now = TickClock.now();
        long fullTicks = TickClock.msToTicks(CHARGE_DURATION_MS);
        List<UUID> ready = new ArrayList<>();
        for (Map.Entry<UUID, Long> e : chargeStartTime.entrySet()) {
            if (now - e.getValue() >= fullTicks) ready.add(e.getKey());
        }
        for (UUID id : ready) {
            class_3222 player = server.method_3760().method_14602(id);
            if (player == null) {
                cancelCharge(id);
                continue;
            }
            releaseCharge(player);
        }
    }

    public static void tick(MinecraftServer server) {
        tickPushWindow(server);
        tickCharges(server);
        long now = TickClock.now();
        Iterator<Map.Entry<UUID, Long>> slowIt = slowdownExpiry.entrySet().iterator();
        while (slowIt.hasNext()) {
            Map.Entry<UUID, Long> e = slowIt.next();
            if (now >= e.getValue()) {
                class_3222 p = server.method_3760().method_14602(e.getKey());
                if (p != null) {
                    removeSlowdown(p, KICK_SLOWDOWN_ID);
                    removeSlowdown(p, DROPKICK_SLOWDOWN_ID);
                }
                slowIt.remove();
            }
        }
    }

    // ===== CLEANUP =====

    public static void cleanup(UUID playerId) {
        chargeStartTime.remove(playerId);
        pushWindowEnd.remove(playerId);
        slowdownExpiry.remove(playerId);
    }

    public static void purgeExpiredCooldowns() {
        // Handled by CooldownManager
    }
}

