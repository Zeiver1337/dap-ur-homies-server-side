package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.util.TickClock;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class HugHandler {
    private static final Map<UUID, UUID> hugPairs = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> hugStart = new ConcurrentHashMap<>();
    private static final long HUG_DURATION_TICKS = TickClock.msToTicks(3000);

    public static class_1269 handleHug(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return class_1269.field_5811;
        if (!ModConfig.get().enableHug) return class_1269.field_5811;
        if (!sp.method_5805() || !target.method_5805()) return class_1269.field_5811;
        if (sp.method_51469() != target.method_51469()) return class_1269.field_5811;
        if (!PlayerPermissionManager.canInitiate(sp, "hug")) {
            Lang.interactionBlocked(sp, "Hug is disabled for you!", "你的拥抱功能已关闭！");
            return class_1269.field_5814;
        }
        if (InteractionCooldowns.rejectIfBlocked(sp, "hug")) return class_1269.field_5814;
        if (!PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")
                && !PlayerPermissionManager.canReceive(target, "hug")) {
            Lang.targetDisabledType(sp, target, "hug");
            return class_1269.field_5814;
        }
        double dist = sp.method_5739(target);
        if (dist > ModConfig.get().hugRange) return class_1269.field_5811;
        if (!startHug(sp, target)) return class_1269.field_5811;
        return class_1269.field_5812;
    }

    public static void tick(MinecraftServer server) {
        if (server == null) return;
        long now = TickClock.now();
        Iterator<Map.Entry<UUID, UUID>> it = hugPairs.entrySet().iterator();
        Set<UUID> processed = new HashSet<>();
        while (it.hasNext()) {
            Map.Entry<UUID, UUID> e = it.next();
            if (processed.contains(e.getKey())) continue;
            UUID id1 = e.getKey(), id2 = e.getValue();
            processed.add(id1); processed.add(id2);

            class_3222 p1 = server.method_3760().method_14602(id1);
            class_3222 p2 = server.method_3760().method_14602(id2);
            if (p1 == null || p2 == null || !p1.method_5805() || !p2.method_5805()
                    || p1.method_51469() != p2.method_51469()) {
                if (p1 != null && p2 != null) clearHugEffects(p1, p2);
                it.remove();
                hugPairs.remove(id2);
                hugStart.remove(id1);
                hugStart.remove(id2);
                continue;
            }

            long elapsed = now - hugStart.getOrDefault(id1, now);
            if (elapsed > HUG_DURATION_TICKS) {
                endHug(p1, p2);
                it.remove();
                hugPairs.remove(id2);
                hugStart.remove(id1);
                hugStart.remove(id2);
                processed.add(id2);
                continue;
            }

            // Apply slowness/mining fatigue with longer duration (refresh every 2 seconds instead of every tick)
            // This avoids creating 4 StatusEffectInstance objects per tick per hug pair
            if (now % 40 == 0 || p1.method_6112(class_1294.field_5909) == null) {
                p1.method_6092(new class_1293(class_1294.field_5909, 60, 5, false, false));
                p1.method_6092(new class_1293(class_1294.field_5901, 60, 4, false, false));
            }
            if (now % 40 == 0 || p2.method_6112(class_1294.field_5909) == null) {
                p2.method_6092(new class_1293(class_1294.field_5909, 60, 5, false, false));
                p2.method_6092(new class_1293(class_1294.field_5901, 60, 4, false, false));
            }

            if (now % 20 == 0) {
                p1.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false));
                p2.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false));
                class_243 mid = p1.method_73189().method_1019(p2.method_73189()).method_1021(0.5);
                class_3218 w = p1.method_51469();
                if (w != null) {
                    w.method_65096(class_2398.field_11201, mid.field_1352, mid.field_1351 + 1.2, mid.field_1350, 2, 0.3, 0.3, 0.3, 0);
                    w.method_43128(null, mid.field_1352, mid.field_1351, mid.field_1350, class_3417.field_14709, class_3419.field_15248, 0.3f, 1.5f);
                }
            }
        }
    }

    public static boolean isHugging(UUID id) {
        return hugPairs.containsKey(id);
    }

    public static void cleanup(UUID id) {
        UUID partner = hugPairs.remove(id);
        if (partner != null) {
            hugPairs.remove(partner);
            hugStart.remove(partner);
        }
        hugStart.remove(id);
    }

    private static boolean startHug(class_3222 p1, class_3222 p2) {
        if (hugPairs.containsKey(p1.method_5667()) || hugPairs.containsKey(p2.method_5667())) return false;
        long now = TickClock.now();
        hugPairs.put(p1.method_5667(), p2.method_5667());
        hugPairs.put(p2.method_5667(), p1.method_5667());
        hugStart.put(p1.method_5667(), now);
        hugStart.put(p2.method_5667(), now);
        Lang.hugStart(p1, p2);
        com.dap.dapurhomies.compat.DanseCompat.playHug(p1, p2); // Danse animation
        return true;
    }

    /** Remove only the amplified effects this handler applied, leaving other sources untouched. */
    private static void clearHugEffects(class_3222 p1, class_3222 p2) {
        clearHugEffects(p1);
        clearHugEffects(p2);
    }

    private static void clearHugEffects(class_3222 player) {
        class_1293 slow = player.method_6112(class_1294.field_5909);
        if (slow != null && slow.method_5578() >= 5) player.method_6016(class_1294.field_5909);
        class_1293 fatigue = player.method_6112(class_1294.field_5901);
        if (fatigue != null && fatigue.method_5578() >= 4) player.method_6016(class_1294.field_5901);
    }

    private static void endHug(class_3222 p1, class_3222 p2) {
        clearHugEffects(p1, p2);
        Lang.hugEnd(p1, p2);
        InteractionCooldowns.applyShared(p1.method_5667(), p2.method_5667(), "hug", ModConfig.get().hugCooldownMs);
    }
}

