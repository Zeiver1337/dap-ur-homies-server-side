package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.DapUrHomiesMod;
import com.dap.dapurhomies.compat.ProtectionCompat;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.util.TickClock;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Map;

public class InteractionRouter {
    // Debounce repeated right-click interaction chains per player pair and tick.
    private static final Map<Long, Long> lastRightClickTick = new HashMap<>();
    private static long lastCleanupTick = 0;
    public static void register() {
        // ===== RIGHT-CLICK INTERACTIONS =====
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.method_8608()) return class_1269.field_5811;
            if (!(player instanceof class_3222 sp)) return class_1269.field_5811;
            if (!(entity instanceof class_3222 target)) return class_1269.field_5811;
            if (!DapUrHomiesMod.isModEnabled()) return class_1269.field_5811;
            if (sp.method_51469() != target.method_51469()) return class_1269.field_5811;

            boolean isAdmin = PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin");
            if (!PlayerPermissionManager.canInitiate(sp, "enabled")) return class_1269.field_5814;
            if (!isAdmin && !PlayerPermissionManager.canReceive(target, "enabled")) return class_1269.field_5814;
            if (!isAdmin && !ProtectionCompat.canInteract(sp, target)) return class_1269.field_5814;

            // P0: holding -> yeet charge
            if (PlayerInteractionState.isHolding(sp) && ModConfig.get().enableGrabYeet)
                return GrabYeetHandler.startCharge(sp);

            if (PlayerInteractionState.isBusyForUse(sp, target))
                return class_1269.field_5811;

            boolean sneaking = sp.method_5715();
            boolean sprinting = sp.method_5624();
            boolean hitAtFeet = hit != null && hit.method_17784().field_1351 < target.method_23318() + 0.8;
            double dist = sp.method_5739(target);

            long nowTick = TickClock.now();
            // Cleanup expired debounce entries (older than 5 seconds = 100 ticks) — throttled to every 20 ticks
            if (nowTick - lastCleanupTick > 20) {
                lastRightClickTick.entrySet().removeIf(e -> nowTick - e.getValue() > 100);
                hugClickTick.entrySet().removeIf(e -> nowTick - e.getValue() > HUG_WINDOW_TICKS * 2);
                lastCleanupTick = nowTick;
            }
            long pairKey = (((long) sp.method_5667().hashCode()) << 32) | (target.method_5667().hashCode() & 0xffffffffL);
            Long lastRc = lastRightClickTick.get(pairKey);
            if (lastRc != null && nowTick - lastRc < 5) return class_1269.field_5811;

            // Hug: BOTH players sneak, aim at each other's HEAD and right-click within the window.
            // Must run BEFORE the sneak branch. If the partner does not answer, fall through to
            // charged Dap instead of swallowing the click entirely.
            if (sneaking && target.method_5715() && ModConfig.get().enableHug
                    && dist <= ModConfig.get().hugRange
                    && aimingAtHead(sp, target) && aimingAtHead(target, sp)) {
                long key = hugKey(sp, target);
                Long last = hugClickTick.get(key);
                if (last != null && nowTick - last <= HUG_WINDOW_TICKS) {
                    class_1269 r = HugHandler.handleHug(sp, target);
                    if (r != class_1269.field_5811) {
                        // A pending charged Dap from the first click must not fire after the hug
                        DapHandler.cancelCharge(sp.method_5667());
                        DapHandler.cancelCharge(target.method_5667());
                        lastRightClickTick.put(pairKey, nowTick);
                        clearHugWindow(sp, target);
                        return r;
                    }
                }
                hugClickTick.put(key, nowTick); // first click: remember and keep processing
            }

            // SNEAK = charged dap (蓄力击掌) / charged DropKick when aiming at the feet
            if (sneaking) {
                if (hitAtFeet && ModConfig.get().enableKick) {
                    if (KickHandler.isCharging(sp.method_5667())) {
                        class_1269 r = KickHandler.releaseCharge(sp, target);
                        if (r != class_1269.field_5811) { lastRightClickTick.put(pairKey, nowTick); return r; }
                    } else {
                        KickHandler.startCharge(sp);
                        lastRightClickTick.put(pairKey, nowTick);
                        return class_1269.field_5812;
                    }
                }
                if (ModConfig.get().enableDap && sp.method_6047().method_7960()) {
                    class_1269 r = DapHandler.startCharge(sp, target);
                    if (r != class_1269.field_5811) { lastRightClickTick.put(pairKey, nowTick); return r; }
                }
                return class_1269.field_5811;
            }

            // SPRINT = Push (疾跑推，不瞄脚部时)
            if (sprinting && !hitAtFeet) {
                if (ModConfig.get().enablePush) {
                    class_1269 r = PushHandler.handlePush(sp, target);
                    if (r != class_1269.field_5811) { lastRightClickTick.put(pairKey, nowTick); return r; }
                }
                return class_1269.field_5811;
            }

            // Kick (aim feet, not sneaking)
            if (hitAtFeet && ModConfig.get().enableKick) {
                class_1269 r = KickHandler.handleKick(sp, target);
                if (r != class_1269.field_5811) { lastRightClickTick.put(pairKey, nowTick); return r; }
            }
            // Slap (behind)
            if (ModConfig.get().enableSlap && isBehind(sp, target)) {
                class_1269 r = SimpleInteractions.handleSlap(sp, target);
                if (r != class_1269.field_5811) { lastRightClickTick.put(pairKey, nowTick); return r; }
            }
            // Right-click fallback = HighFive/Dap (击掌)
            if (sp.method_6047().method_7960() && ModConfig.get().enableDap) {
                class_1269 r = DapHandler.handleNormalDap(sp, target);
                if (r != class_1269.field_5811) { lastRightClickTick.put(pairKey, nowTick); return r; }
            }
            return class_1269.field_5811;
        });

        // ===== LEFT-CLICK INTERACTIONS (AttackEntityCallback) =====
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;
            if (!(player instanceof class_3222 sp)) return class_1269.field_5811;
            if (!(entity instanceof class_3222 target)) return class_1269.field_5811;
            if (!DapUrHomiesMod.isModEnabled()) return class_1269.field_5811;
            if (sp.method_51469() != target.method_51469()) return class_1269.field_5811;

            boolean isAdmin = PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin");

            // Master switch check
            if (!PlayerPermissionManager.canInitiate(sp, "enabled")) return class_1269.field_5811;
            if (!isAdmin && !PlayerPermissionManager.canReceive(target, "enabled")) return class_1269.field_5811;
            if (!isAdmin && !ProtectionCompat.canInteract(sp, target)) return class_1269.field_5811;

            // State exclusion
            if (PlayerInteractionState.isBusyForAttack(sp, target))
                return class_1269.field_5811;

            // Shift+左键 = Grab (if not holding)
            if (sp.method_5715() && ModConfig.get().enableGrabYeet
                    && !GrabYeetHandler.isHolding(sp) && !GrabYeetHandler.isHeld(sp)) {
                class_1269 result = GrabYeetHandler.tryGrab(sp, target);
                if (result != class_1269.field_5811) return result;
            }

            // left-click held target = throw if charged, else drop
            if (GrabYeetHandler.isHolding(sp) && ModConfig.get().enableGrabYeet) {
                if (GrabYeetHandler.isCharging(sp.method_5667())) return GrabYeetHandler.releaseCharge(sp);
                class_1269 r = GrabYeetHandler.tryDrop(sp);
                return (r == class_1269.field_5811) ? class_1269.field_5814 : r;
            }

            // Left-click does NOT trigger dap/highfive (only right-click does).
            return class_1269.field_5811;
        });
    }

    private static boolean isBehind(class_3222 attacker, class_3222 target) {
        net.minecraft.class_243 look = target.method_5828(1.0f);
        net.minecraft.class_243 to = attacker.method_73189().method_1020(target.method_73189()).method_1029();
        return look.method_1026(to) <= 0.0;
    }

    // ---- Hug mutual-detection helpers ----
    private static final Map<Long, Long> hugClickTick = new HashMap<>(); // pairKey -> last tick initiator clicked
    private static final long HUG_WINDOW_TICKS = 10; // 0.5s: enough for two humans to answer each other

    private static long hugKey(class_3222 a, class_3222 b) {
        // order-independent pair key
        int h1 = a.method_5667().hashCode(), h2 = b.method_5667().hashCode();
        long lo = Math.min(h1, h2), hi = Math.max(h1, h2);
        return (hi << 32) | (lo & 0xffffffffL);
    }
    private static void clearHugWindow(class_3222 a, class_3222 b) {
        hugClickTick.remove(hugKey(a, b));
    }
    private static boolean aimingAtHead(class_3222 viewer, class_3222 target) {
        net.minecraft.class_243 eye = viewer.method_5836(1.0f);
        net.minecraft.class_243 look = viewer.method_5828(1.0f);
        net.minecraft.class_243 head = target.method_73189().method_1031(0, target.method_5751(), 0);
        net.minecraft.class_243 toHead = head.method_1020(eye).method_1029();
        return look.method_1026(toHead) > 0.95;   // ~18° cone on head
    }
}

