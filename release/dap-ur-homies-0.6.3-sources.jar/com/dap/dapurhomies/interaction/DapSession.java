package com.dap.dapurhomies.interaction;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * DapSession - ported from original Dap-ur-homie project.
 * Manages a two-player dap session where both players are smoothly moved
 * to face each other at a specific distance, creating a cinematic interaction.
 */
public class DapSession {

    private final UUID playerAId;
    private final UUID playerBId;
    private class_243 targetA;
    private class_243 targetB;

    private int tickCount;
    private boolean positioningComplete;

    private final double targetDistance;
    private final double lerpSpeed;
    private final DapType type;

    private Runnable onPositioningComplete;

    public enum DapType {
        NORMAL_DAP,
        PERFECT_DAP,
        FIRE_DAP,
        FIRE_COMBO,
        DAP_HOLD
    }

    public DapSession(UUID playerA, UUID playerB, double targetDistance, DapType type) {
        this.playerAId = playerA;
        this.playerBId = playerB;
        this.targetDistance = targetDistance;
        this.type = type;
        this.tickCount = 0;
        this.positioningComplete = false;

        if (type == DapType.PERFECT_DAP) {
            this.lerpSpeed = 0.95;
        } else {
            this.lerpSpeed = 0.75;
        }
    }

    public void onComplete(Runnable callback) {
        this.onPositioningComplete = callback;
    }

    public void tick(MinecraftServer server) {
        class_3222 playerA = server.method_3760().method_14602(playerAId);
        class_3222 playerB = server.method_3760().method_14602(playerBId);

        // Safety checks - if either player is gone, force complete and end session
        if (playerA == null || playerB == null || playerA.method_31481() || playerB.method_31481()) {
            forceComplete(playerA, playerB);
            return;
        }

        // Timeout safety (5 seconds = 100 ticks)
        if (tickCount > 100) {
            forceComplete(playerA, playerB);
            return;
        }

        freezePlayers(playerA, playerB);
        computeTargets(playerA, playerB);
        smoothMoveToTargets(playerA, playerB);
        makeFaceEachOther(playerA, playerB);
        playerA.method_23667(net.minecraft.class_1268.field_5808, true);
        playerB.method_23667(net.minecraft.class_1268.field_5808, true);

        if (!positioningComplete) {
            checkPositioningComplete(playerA, playerB);
        }

        tickCount++;
    }

    private void freezePlayers(class_3222 playerA, class_3222 playerB) {
        playerA.method_18799(class_243.field_1353);
        playerB.method_18799(class_243.field_1353);
        playerA.field_6037 = true; // sync velocity to client
        playerB.field_6037 = true;
        playerA.field_6017 = 0;
        playerB.field_6017 = 0;
    }

    private void computeTargets(class_3222 playerA, class_3222 playerB) {
        class_243 posA = playerA.method_73189();
        class_243 posB = playerB.method_73189();

        class_243 midpoint = posA.method_1019(posB).method_1021(0.5);

        class_243 direction = posB.method_1020(posA);
        if (direction.method_1027() < 1e-6) {
            direction = new class_243(1, 0, 0);
        }
        direction = direction.method_1029();

        double halfDistance = targetDistance / 2.0;
        targetA = midpoint.method_1020(direction.method_1021(halfDistance));
        targetB = midpoint.method_1019(direction.method_1021(halfDistance));

        double targetY = Math.max(posA.field_1351, posB.field_1351);

        class_3218 world = (class_3218) playerA.method_51469();
        class_2338 groundPos = class_2338.method_49637(midpoint.field_1352, targetY - 1, midpoint.field_1350);
        if (world.method_8320(groundPos).method_26215()) {
            targetY = Math.min(posA.field_1351, posB.field_1351);
        }

        targetA = new class_243(targetA.field_1352, targetY, targetA.field_1350);
        targetB = new class_243(targetB.field_1352, targetY, targetB.field_1350);
    }

    private void smoothMoveToTargets(class_3222 playerA, class_3222 playerB) {
        class_243 currentA = playerA.method_73189();
        class_243 currentB = playerB.method_73189();

        class_243 newPosA = new class_243(
                lerp(currentA.field_1352, targetA.field_1352, lerpSpeed),
                lerp(currentA.field_1351, targetA.field_1351, lerpSpeed),
                lerp(currentA.field_1350, targetA.field_1350, lerpSpeed)
        );

        class_243 newPosB = new class_243(
                lerp(currentB.field_1352, targetB.field_1352, lerpSpeed),
                lerp(currentB.field_1351, targetB.field_1351, lerpSpeed),
                lerp(currentB.field_1350, targetB.field_1350, lerpSpeed)
        );

        playerA.method_48105((class_3218) playerA.method_51469(), newPosA.field_1352, newPosA.field_1351, newPosA.field_1350,
                java.util.Set.of(), playerA.method_36454(), playerA.method_36455(), false);
        playerB.method_48105((class_3218) playerB.method_51469(), newPosB.field_1352, newPosB.field_1351, newPosB.field_1350,
                java.util.Set.of(), playerB.method_36454(), playerB.method_36455(), false);
    }

    private void makeFaceEachOther(class_3222 playerA, class_3222 playerB) {
        class_243 posA = playerA.method_73189();
        class_243 posB = playerB.method_73189();

        double dx = posB.field_1352 - posA.field_1352;
        double dz = posB.field_1350 - posA.field_1350;
        float yawA = (float) (Math.atan2(dz, dx) * 180 / Math.PI) - 90;
        float yawB = yawA + 180;

        playerA.method_36456(yawA);
        playerA.method_5636(yawA);
        playerA.method_5847(yawA);
        playerA.field_5982 = yawA;
        playerA.field_6220 = yawA;
        playerA.field_6259 = yawA;

        playerB.method_36456(yawB);
        playerB.method_5636(yawB);
        playerB.method_5847(yawB);
        playerB.field_5982 = yawB;
        playerB.field_6220 = yawB;
        playerB.field_6259 = yawB;

        playerA.method_48105((class_3218) playerA.method_51469(), posA.field_1352, posA.field_1351, posA.field_1350,
                java.util.Set.of(), yawA, playerA.method_36455(), false);
        playerB.method_48105((class_3218) playerB.method_51469(), posB.field_1352, posB.field_1351, posB.field_1350,
                java.util.Set.of(), yawB, playerB.method_36455(), false);
    }

    private void checkPositioningComplete(class_3222 playerA, class_3222 playerB) {
        double distA = playerA.method_73189().method_1022(targetA);
        double distB = playerB.method_73189().method_1022(targetB);

        double threshold = (type == DapType.PERFECT_DAP) ? 0.35 : 0.25;
        if (distA < threshold && distB < threshold) {
            positioningComplete = true;

            if (onPositioningComplete != null) {
                onPositioningComplete.run();
            }

            this.tickCount = 99; // Force near-timeout so session ends next tick
        }
    }

    private void forceComplete(class_3222 playerA, class_3222 playerB) {
        if (!positioningComplete) {
            positioningComplete = true;
            if (onPositioningComplete != null) {
                onPositioningComplete.run();
            }
        }
    }

    private double lerp(double current, double target, double factor) {
        return current + (target - current) * factor;
    }

    public UUID getPlayerAId() { return playerAId; }
    public UUID getPlayerBId() { return playerBId; }
    public boolean isPositioningComplete() { return positioningComplete; }
    public int getTickCount() { return tickCount; }
}

