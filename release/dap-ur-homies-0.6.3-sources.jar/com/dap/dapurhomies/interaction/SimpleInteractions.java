package com.dap.dapurhomies.interaction;

import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.util.CooldownManager;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Simple interactions: slap, clap, mario jump.
 * Uses ConcurrentHashMap for thread safety and CooldownManager for unified cooldowns.
 */
public class SimpleInteractions {
    private static final Map<UUID, Integer> marioJumpTicks = new ConcurrentHashMap<>();

    public static void tick(net.minecraft.server.MinecraftServer server) {
        Iterator<Map.Entry<UUID, Integer>> it = marioJumpTicks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            class_3222 p = server.method_3760().method_14602(e.getKey());
            if (p == null || !p.method_5805()) { it.remove(); continue; }
            int tick = e.getValue();
            if (tick >= 30) { it.remove(); continue; }
            if (tick < 8) { p.method_5762(0, 0.35, 0); }
            else if (tick < 15) { p.method_5762(0, 0.15, 0); }
            if (tick % 2 == 0) {
                class_243 pos = p.method_73189().method_1031(0, 0.5, 0);
                class_3218 pw = p.method_51469();
                if (pw != null) {
                    pw.method_65096(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, 2, 0.2, 0.2, 0.2, 0.02);
                }
            }
            e.setValue(tick + 1);
        }
    }

    public static class_1269 handleSlap(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return class_1269.field_5811;
        if (!ModConfig.get().enableSlap) return class_1269.field_5811;
        if (sp.method_5739(target) > ModConfig.get().slapRange) return class_1269.field_5811;
        if (!PlayerPermissionManager.canInitiate(sp, "slap")) {
            Lang.interactionBlocked(sp, "Slap is disabled for you!", "你的拍巴掌功能已关闭！");
            return class_1269.field_5814;
        }
        if (InteractionCooldowns.rejectIfBlocked(sp, "slap")) return class_1269.field_5814;
        if (!PlayerPermissionManager.hasPermission(sp, "dap-ur-homies.admin")
                && !PlayerPermissionManager.canReceive(target, "slap")) {
            Lang.targetDisabledType(sp, target, "slap");
            return class_1269.field_5814;
        }
        class_243 targetLook = target.method_5828(1.0f);
        class_243 toAttacker = sp.method_73189().method_1020(target.method_73189()).method_1029();
        double dot = targetLook.method_1026(toAttacker);
        // A slap must come from behind: dot <= 0 means the target is facing away.
        // A positive dot means the target faces the attacker, so this is not a slap.
        if (dot > 0.0) return class_1269.field_5811;
        executeSlap(sp, target);
        return class_1269.field_5812;
    }

    private static void executeSlap(class_3222 sp, class_3222 target) {
        if (sp == null || target == null) return;
        class_3218 w = sp.method_51469();
        if (w == null) return;
        class_243 hitPos = target.method_73189().method_1031(0, 1.6, 0);
        target.method_6092(new class_1293(class_1294.field_5909, 40, 3, false, false));
        w.method_65096(class_2398.field_11205, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350, 8, 0.15, 0.1, 0.15, 0.15);
        w.method_65096(class_2398.field_11227, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350, 3, 0.1, 0.05, 0.1, 0.05);
        w.method_43128(null, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350, class_3417.field_14840, class_3419.field_15248, 1.0f, 1.8f);
        sp.method_23667(net.minecraft.class_1268.field_5808, true);
        Lang.slapSuccess(sp, target);
        InteractionCooldowns.apply(sp.method_5667(), "slap", ModConfig.get().slapCooldownMs);
        com.dap.dapurhomies.compat.DanseCompat.playSlap(sp, target); // Danse animation
    }

    public static void onClap(class_3222 player) {
        if (player == null) return;
        if (!ModConfig.get().enableClap) return;
        if (!PlayerPermissionManager.canInitiate(player, "clap")) {
            Lang.interactionBlocked(player, "Clap is disabled for you!", "你的鼓掌功能已关闭！");
            return;
        }
        if (InteractionCooldowns.isBlocked(player, "clap")) return;
        class_3218 w = player.method_51469();
        if (w == null) return;
        class_243 pos = player.method_73189().method_1031(0, 1.2, 0);
        w.method_65096(class_2398.field_11205, pos.field_1352, pos.field_1351, pos.field_1350, 4, 0.1, 0.1, 0.1, 0.03);
        // Use ClapLooper for a rhythmic 2-second clap sound effect
        com.dap.dapurhomies.util.ClapLooper.start(w, pos,
                com.dap.dapurhomies.config.ModConfig.get().highFiveSoundTicks,
                com.dap.dapurhomies.config.ModConfig.get().clapIntervalTicks);
        player.method_23667(net.minecraft.class_1268.field_5808, true);
        Lang.clapSuccess(player);
        InteractionCooldowns.apply(player.method_5667(), "clap", 500);
        com.dap.dapurhomies.compat.DanseCompat.playClap(player); // Danse animation
    }

    public static void onMarioJump(class_3222 player) {
        if (player == null) return;
        if (!PlayerPermissionManager.canInitiate(player, "dap")) return;
        if (InteractionCooldowns.isBlocked(player, "mario")) return;
        class_3218 w = player.method_51469();
        if (w == null) return;
        class_243 pos = player.method_73189();
        w.method_65096(class_2398.field_11204, pos.field_1352, pos.field_1351, pos.field_1350, 10, 0.4, 0.1, 0.4, 0.08);
        w.method_65096(class_2398.field_11207, pos.field_1352, pos.field_1351 + 0.5, pos.field_1350, 5, 0.2, 0.3, 0.2, 0.03);
        w.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_18311.comp_349(), class_3419.field_15248, 1.0f, 1.5f);
        w.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14778, class_3419.field_15248, 0.6f, 1.8f);
        marioJumpTicks.put(player.method_5667(), 0);
        CooldownManager.setCooldown(player.method_5667(), "mario", 60); // 60 ticks = 3s
        Lang.marioJumpSuccess(player);
        com.dap.dapurhomies.compat.DanseCompat.playMarioJump(player); // Danse animation
    }

    public static void cleanup(UUID playerId) {
        marioJumpTicks.remove(playerId);
    }
}

