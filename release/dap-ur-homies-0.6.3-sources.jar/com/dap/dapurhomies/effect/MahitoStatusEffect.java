package com.dap.dapurhomies.effect;

import eu.pb4.polymer.core.api.other.PolymerStatusEffect;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_4081;
import xyz.nucleoid.packettweaker.PacketContext;

/**
 * Mahito status effect — soul manipulation distortion.
 * Actual effect logic is handled in DapUrHomiesMod server tick
 * to avoid method-signature compatibility issues across MC versions.
 */
public class MahitoStatusEffect extends class_1291 implements PolymerStatusEffect {
    public MahitoStatusEffect() {
        super(class_4081.field_18273, 0x9b59b6);
    }

    @Override
    public class_1291 getPolymerReplacement(class_1291 effect, PacketContext context) {
        return class_1294.field_5908.comp_349();
    }
}

