package com.dap.dapurhomies;

import com.dap.dapurhomies.command.DapCommands;
import com.dap.dapurhomies.command.InteractionCommands;
import com.dap.dapurhomies.compat.DanseCompat;
import com.dap.dapurhomies.compat.ProtectionCompat;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.effect.MahitoStatusEffect;
import com.dap.dapurhomies.interaction.InteractionModules;
import com.dap.dapurhomies.item.MahitoPotionItem;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.dap.dapurhomies.update.UpdateChecker;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1291;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DapUrHomiesMod implements ModInitializer {
    public static final String MOD_ID = "dap-ur-homies";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static class_1291 MAHITO_EFFECT;
    public static class_6880<class_1291> MAHITO_EFFECT_ENTRY;
    public static class_1792 MAHITO_POTION;
    static boolean modEnabled = true;
    static MinecraftServer serverInstance;

    public static MinecraftServer getServer() { return serverInstance; }

    @Override
    public void onInitialize() {
        LOGGER.info("[DapUrHomies] Server-side mod initializing for MC 1.21.11...");

        ModConfig.load();
        Lang.loadGlobalLanguage();
        PlayerPermissionManager.init();

        class_2960 effectId = class_2960.method_60655(MOD_ID, "mahito");
        MAHITO_EFFECT = new MahitoStatusEffect();
        class_2378.method_10230(class_7923.field_41174, effectId, MAHITO_EFFECT);
        MAHITO_EFFECT_ENTRY = class_7923.field_41174.method_10223(effectId).orElseThrow();

        class_2960 itemId = class_2960.method_60655(MOD_ID, "mahito_potion");
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, itemId);
        MAHITO_POTION = new MahitoPotionItem(new class_1792.class_1793().method_7889(1).method_63686(itemKey));
        class_2378.method_10230(class_7923.field_41178, itemId, MAHITO_POTION);
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(entries -> entries.method_45421(MAHITO_POTION));

        InteractionModules.registerAll();

        // Register Polymer resource pack for Mahito potion textures
        PolymerResourcePackUtils.addModAssets(MOD_ID);

        registerCommands();

        ModLifecycle.register();
        UpdateChecker.initialize();

        LOGGER.info("[DapUrHomies] Initialized. Optional integrations: LuckPerms=" + PlayerPermissionManager.isLuckPermsActive()
                + ", Danse=" + DanseCompat.isDanseLoaded()
                + ", protection=" + (ProtectionCompat.isAnyProtectionLoaded() ? ProtectionCompat.getLoadedMods().trim() : "none")
                + " (Polymer is bundled, no separate install needed)");
    }

    public static boolean isModEnabled() { return modEnabled; }
    public static void setModEnabled(boolean enabled) { modEnabled = enabled; }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, reg, env) -> {
            DapCommands.register(dispatcher);
            InteractionCommands.register(dispatcher);
        });
    }
}
