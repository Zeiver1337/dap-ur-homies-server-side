package com.dap.dapurhomies.command;

import com.dap.dapurhomies.DapUrHomiesMod;
import com.dap.dapurhomies.Lang;
import com.dap.dapurhomies.ModLifecycle;
import com.dap.dapurhomies.config.ModConfig;
import com.dap.dapurhomies.permission.PlayerPermissionManager;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class DapCommands {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        var dapRoot = class_2170.method_9247("dap");

        // /dap on [player]
        dapRoot.then(class_2170.method_9247("on")
            .executes(c -> {
                class_3222 p = c.getSource().method_9207();
                if (PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                    if (DapUrHomiesMod.isModEnabled()) Lang.alreadyEnabled(p);
                    else { DapUrHomiesMod.setModEnabled(true); Lang.modEnabled(p); }
                } else {
                    if (com.dap.dapurhomies.util.AdminManager.isForceDisabled(p.method_5667())) {
                        Lang.interactionBlocked(p, "An admin disabled this for you!", "管理员已关闭你的交互功能！");
                        return 0;
                    }
                    PlayerPermissionManager.set(p, "enabled", true);
                    Lang.playerEnabled(p);
                }
                return 1;
            })
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    class_3222 t = class_2186.method_9315(c, "player");
                    com.dap.dapurhomies.util.AdminManager.setForceDisabled(t.method_5667(), false);
                    PlayerPermissionManager.set(t, "enabled", true);
                    Lang.playerEnabledByAdmin(p, t);
                    return 1;
                })));

        // /dap off [player]
        dapRoot.then(class_2170.method_9247("off")
            .executes(c -> {
                class_3222 p = c.getSource().method_9207();
                if (PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                    if (!DapUrHomiesMod.isModEnabled()) Lang.alreadyDisabled(p);
                    else ModLifecycle.disableModAndCleanup(p);
                } else {
                    PlayerPermissionManager.set(p, "enabled", false);
                    Lang.playerDisabled(p);
                }
                return 1;
            })
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    class_3222 t = class_2186.method_9315(c, "player");
                    com.dap.dapurhomies.util.AdminManager.setForceDisabled(t.method_5667(), true);
                    PlayerPermissionManager.set(t, "enabled", false);
                    Lang.playerDisabledByAdmin(p, t);
                    return 1;
                })));

        // /dap status [player]
        dapRoot.then(class_2170.method_9247("status")
            .executes(c -> {
                class_3222 p = c.getSource().method_9207();
                Lang.modStatus(p, DapUrHomiesMod.isModEnabled());
                Lang.playerStatus(p, PlayerPermissionManager.get(p));
                return 1;
            })
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    class_3222 t = class_2186.method_9315(c, "player");
                    Lang.modStatus(p, DapUrHomiesMod.isModEnabled());
                    Lang.playerStatus(p, t, PlayerPermissionManager.get(t));
                    return 1;
                })));

        // /dap reload
        dapRoot.then(class_2170.method_9247("reload")
            .executes(c -> {
                class_3222 p = c.getSource().method_9207();
                if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                    Lang.noPermission(p); return 0;
                }
                try {
                    ModConfig.load();
                    Lang.configReloaded(p);
                } catch (Exception e) {
                    Lang.configReloadFailed(p);
                }
                return 1;
            }));

        // /dap admincooldown on|off
        dapRoot.then(class_2170.method_9247("admincooldown")
            .then(class_2170.method_9247("on")
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    ModConfig.get().adminBypassCooldown = true;
                    ModConfig.save();
                    Lang.adminCooldownToggled(p, true);
                    return 1;
                }))
            .then(class_2170.method_9247("off")
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    ModConfig.get().adminBypassCooldown = false;
                    ModConfig.save();
                    Lang.adminCooldownToggled(p, false);
                    return 1;
                })));

        String[] types = {"dap", "grab", "push", "kick", "hug", "slap", "clap", "danse"};
        for (String type : types) {
            var typeLit = class_2170.method_9247(type);
            typeLit.then(class_2170.method_9247("on")
                .executes(c -> toggleType(c.getSource().method_9207(), type, true, null))
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .executes(c -> {
                        class_3222 p = c.getSource().method_9207();
                        if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                            Lang.noPermission(p); return 0;
                        }
                        return toggleType(p, type, true, class_2186.method_9315(c, "player"));
                    })));
            typeLit.then(class_2170.method_9247("off")
                .executes(c -> toggleType(c.getSource().method_9207(), type, false, null))
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .executes(c -> {
                        class_3222 p = c.getSource().method_9207();
                        if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                            Lang.noPermission(p); return 0;
                        }
                        return toggleType(p, type, false, class_2186.method_9315(c, "player"));
                    })));
            dapRoot.then(typeLit);
        }

        // /dap ban <player> <type|all> <minutes>
        dapRoot.then(class_2170.method_9247("ban")

            .then(class_2170.method_9244("player", class_2186.method_9305())
            .then(class_2170.method_9244("type", com.mojang.brigadier.arguments.StringArgumentType.word())
            .then(class_2170.method_9244("minutes", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1))
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    class_3222 t = class_2186.method_9315(c, "player");
                    String type = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "type");
                    if (!com.dap.dapurhomies.util.AdminManager.isValidType(type)) {
                        Lang.invalidCooldownType(p); return 0;
                    }
                    int min = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "minutes");
                    com.dap.dapurhomies.util.AdminManager.ban(t.method_5667(), type, min * 1200L);
                    c.getSource().method_9226(() -> class_2561.method_43470("Banned " + t.method_5477().getString() + " from " + type + " for " + min + "min"), false);
                    return 1;
                })))));

        // /dap unban <player> <type|all>
        dapRoot.then(class_2170.method_9247("unban")

            .then(class_2170.method_9244("player", class_2186.method_9305())
            .then(class_2170.method_9244("type", com.mojang.brigadier.arguments.StringArgumentType.word())
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    class_3222 t = class_2186.method_9315(c, "player");
                    String type = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "type");
                    if (!com.dap.dapurhomies.util.AdminManager.isValidType(type)) {
                        Lang.invalidCooldownType(p); return 0;
                    }
                    com.dap.dapurhomies.util.AdminManager.unban(t.method_5667(), type);
                    c.getSource().method_9226(() -> class_2561.method_43470("Unbanned " + t.method_5477().getString()), false);
                    return 1;
                }))));

        // /dap cooldown ms|set ...
        dapRoot.then(class_2170.method_9247("cooldown")
            .then(class_2170.method_9247("ms")
            .then(class_2170.method_9244("type", com.mojang.brigadier.arguments.StringArgumentType.string())
                .suggests((ctx, builder) -> {
                    String[] suggest = {"dap", "highFive", "grab", "push", "kick", "hug", "slap"};
                    for (String t : suggest) builder.suggest(t);
                    return builder.buildFuture();
                })
                .then(class_2170.method_9244("ms", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 300000))
                    .executes(c -> {
                        class_3222 p = c.getSource().method_9207();
                        if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                            Lang.noPermission(p); return 0;
                        }
                        String type = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "type");
                        int ms = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "ms");
                        switch (type) {
                            case "dap" -> ModConfig.get().dapCooldownMs = ms;
                            case "highFive" -> ModConfig.get().highFiveCooldownMs = ms;
                            case "grab" -> ModConfig.get().grabCooldownMs = ms;
                            case "push" -> ModConfig.get().pushCooldownMs = ms;
                            case "kick" -> ModConfig.get().kickCooldownMs = ms;
                            case "hug" -> ModConfig.get().hugCooldownMs = ms;
                            case "slap" -> ModConfig.get().slapCooldownMs = ms;
                            default -> { Lang.invalidCooldownType(p); return 0; }
                        }
                        ModConfig.save();
                        Lang.cooldownSet(p, type, ms);
                        return 1;
                    }))))
            .then(class_2170.method_9247("set")
            .then(class_2170.method_9244("type", com.mojang.brigadier.arguments.StringArgumentType.word())
            .then(class_2170.method_9244("seconds", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1))
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    String type = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "type");
                    if (!com.dap.dapurhomies.util.AdminManager.isValidType(type) || "all".equals(type)) {
                        Lang.invalidCooldownType(p); return 0;
                    }
                    long ticks = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "seconds") * 20L;
                    com.dap.dapurhomies.util.AdminManager.setGlobalCooldown(type, ticks);
                    c.getSource().method_9226(() -> class_2561.method_43470("Global " + type + " cooldown = " + (ticks/20) + "s"), false);
                    return 1;
                })
                .then(class_2170.method_9244("player", class_2186.method_9305())
                    .executes(c -> {
                        class_3222 p = c.getSource().method_9207();
                        if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) { Lang.noPermission(p); return 0; }
                        String type = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "type");
                        if (!com.dap.dapurhomies.util.AdminManager.isValidType(type) || "all".equals(type)) {
                            Lang.invalidCooldownType(p); return 0;
                        }
                        long ticks = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "seconds") * 20L;
                        class_3222 t = class_2186.method_9315(c, "player");
                        com.dap.dapurhomies.util.AdminManager.setPlayerCooldown(t.method_5667(), type, ticks);
                        c.getSource().method_9226(() -> class_2561.method_43470(t.method_5477().getString() + " " + type + " cooldown = " + (ticks/20) + "s"), false);
                        return 1;
                    }))))));

        // /dap sound <ticks>
        dapRoot.then(class_2170.method_9247("sound")

            .then(class_2170.method_9244("ticks", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1))
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) { Lang.noPermission(p); return 0; }
                    ModConfig.get().highFiveSoundTicks = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "ticks");
                    ModConfig.save();
                    c.getSource().method_9226(() -> class_2561.method_43470("HighFive sound = " + ModConfig.get().highFiveSoundTicks + " ticks"), false);
                    return 1;
                })));

        // /dap chargedmode <0|1>
        dapRoot.then(class_2170.method_9247("chargedmode")
            .then(class_2170.method_9244("mode", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 1))
                .executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!PlayerPermissionManager.hasPermission(p, "dap-ur-homies.admin")) {
                        Lang.noPermission(p); return 0;
                    }
                    int mode = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "mode");
                    ModConfig.get().chargedDapMode = mode;
                    ModConfig.save();
                    Lang.chargedModeSet(p, mode);
                    return 1;
                })));

        // Default /dap
        dapRoot.executes(c -> {
            c.getSource().method_9226(() -> Lang.t(
                "\u00a7e[Dap] \u00a7f/dap on|off [player] | /dap <type> on|off [player] | /dap status [player]",
                "\u00a7e[\u78b0\u62f3] \u00a7f/dap on|off [\u73a9\u5bb6] | /dap <\u7c7b\u578b> on|off [\u73a9\u5bb6] | /dap status [\u73a9\u5bb6]"
            ), false);
            return 1;
        });

        dispatcher.register(dapRoot);
    }

    private static int toggleType(class_3222 sender, String type, boolean value, class_3222 target) {
        class_3222 actualTarget = (target != null) ? target : sender;
        PlayerPermissionManager.set(actualTarget, type, value);
        if (target != null && !sender.equals(target)) {
            Lang.typeToggledByAdmin(sender, target, type, value);
        } else {
            Lang.typeToggled(sender, type, value);
        }
        return 1;
    }
}
