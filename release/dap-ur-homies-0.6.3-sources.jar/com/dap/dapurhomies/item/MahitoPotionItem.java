package com.dap.dapurhomies.item;

import com.dap.dapurhomies.DapUrHomiesMod;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_5328;
import xyz.nucleoid.packettweaker.PacketContext;

public class MahitoPotionItem extends class_1792 implements PolymerItem {
    public MahitoPotionItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (!world.method_8608() && user instanceof class_1657 player) {
            player.method_6092(new class_1293(
                DapUrHomiesMod.MAHITO_EFFECT_ENTRY, 6000, 0, false, true, true
            ));
            if (!player.method_31549().field_7477) {
                stack.method_7934(1);
            }
        }
        // Return glass bottle when potion is consumed (standard MC behavior)
        return stack.method_7960() ? new class_1799(class_1802.field_8469) : stack;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 32;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        return class_5328.method_29282(world, user, hand);
    }

    @Override
    public class_1792 getPolymerItem(class_1799 itemStack, PacketContext context) {
        return class_1802.field_8574;
    }

    @Override
    public class_1799 getPolymerItemStack(class_1799 itemStack, class_1836 tooltipType, PacketContext context) {
        return PolymerItemUtils.createItemStack(itemStack, tooltipType, context);
    }
}

